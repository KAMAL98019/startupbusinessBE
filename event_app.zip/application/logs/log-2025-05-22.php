<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-05-22 16:15:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:15:02 --> Config Class Initialized
INFO - 2025-05-22 16:15:02 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:15:02 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:15:02 --> Utf8 Class Initialized
INFO - 2025-05-22 16:15:02 --> URI Class Initialized
INFO - 2025-05-22 16:15:02 --> Router Class Initialized
INFO - 2025-05-22 16:15:02 --> Output Class Initialized
INFO - 2025-05-22 16:15:02 --> Security Class Initialized
DEBUG - 2025-05-22 16:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:15:02 --> Input Class Initialized
INFO - 2025-05-22 16:15:02 --> Language Class Initialized
INFO - 2025-05-22 16:15:02 --> Loader Class Initialized
INFO - 2025-05-22 16:15:02 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:15:02 --> Controller Class Initialized
DEBUG - 2025-05-22 16:15:02 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-22 16:15:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-22 16:15:02 --> Helper loaded: inflector_helper
INFO - 2025-05-22 16:15:02 --> Email Class Initialized
INFO - 2025-05-22 16:15:02 --> Final output sent to browser
DEBUG - 2025-05-22 16:15:02 --> Total execution time: 0.0444
ERROR - 2025-05-22 16:17:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:17:03 --> Config Class Initialized
INFO - 2025-05-22 16:17:03 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:17:03 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:17:03 --> Utf8 Class Initialized
INFO - 2025-05-22 16:17:03 --> URI Class Initialized
INFO - 2025-05-22 16:17:03 --> Router Class Initialized
INFO - 2025-05-22 16:17:03 --> Output Class Initialized
INFO - 2025-05-22 16:17:03 --> Security Class Initialized
DEBUG - 2025-05-22 16:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:17:03 --> Input Class Initialized
INFO - 2025-05-22 16:17:03 --> Language Class Initialized
INFO - 2025-05-22 16:17:03 --> Loader Class Initialized
INFO - 2025-05-22 16:17:03 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:17:03 --> Controller Class Initialized
DEBUG - 2025-05-22 16:17:03 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-22 16:17:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-22 16:17:03 --> Helper loaded: inflector_helper
INFO - 2025-05-22 16:17:03 --> Email Class Initialized
INFO - 2025-05-22 16:17:03 --> Final output sent to browser
DEBUG - 2025-05-22 16:17:03 --> Total execution time: 0.0335
ERROR - 2025-05-22 16:38:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:38:06 --> Config Class Initialized
INFO - 2025-05-22 16:38:06 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:38:06 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:38:06 --> Utf8 Class Initialized
INFO - 2025-05-22 16:38:06 --> URI Class Initialized
INFO - 2025-05-22 16:38:06 --> Router Class Initialized
INFO - 2025-05-22 16:38:06 --> Output Class Initialized
INFO - 2025-05-22 16:38:06 --> Security Class Initialized
DEBUG - 2025-05-22 16:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:38:06 --> Input Class Initialized
INFO - 2025-05-22 16:38:06 --> Language Class Initialized
INFO - 2025-05-22 16:38:06 --> Loader Class Initialized
INFO - 2025-05-22 16:38:06 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:38:06 --> Controller Class Initialized
ERROR - 2025-05-22 16:39:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:39:17 --> Config Class Initialized
INFO - 2025-05-22 16:39:17 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:39:18 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:39:18 --> Utf8 Class Initialized
INFO - 2025-05-22 16:39:18 --> URI Class Initialized
INFO - 2025-05-22 16:39:18 --> Router Class Initialized
INFO - 2025-05-22 16:39:18 --> Output Class Initialized
INFO - 2025-05-22 16:39:18 --> Security Class Initialized
DEBUG - 2025-05-22 16:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:39:18 --> Input Class Initialized
INFO - 2025-05-22 16:39:18 --> Language Class Initialized
INFO - 2025-05-22 16:39:18 --> Loader Class Initialized
INFO - 2025-05-22 16:39:18 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:39:18 --> Controller Class Initialized
DEBUG - 2025-05-22 16:39:18 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-22 16:39:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-22 16:39:18 --> Helper loaded: inflector_helper
INFO - 2025-05-22 16:39:18 --> Email Class Initialized
ERROR - 2025-05-22 16:39:20 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp64\www\event_app\system\libraries\Email.php 1903
INFO - 2025-05-22 16:39:20 --> Language file loaded: language/english/email_lang.php
INFO - 2025-05-22 16:39:20 --> Final output sent to browser
DEBUG - 2025-05-22 16:39:20 --> Total execution time: 2.1604
ERROR - 2025-05-22 16:41:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:41:55 --> Config Class Initialized
INFO - 2025-05-22 16:41:55 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:41:55 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:41:55 --> Utf8 Class Initialized
INFO - 2025-05-22 16:41:55 --> URI Class Initialized
INFO - 2025-05-22 16:41:55 --> Router Class Initialized
INFO - 2025-05-22 16:41:55 --> Output Class Initialized
INFO - 2025-05-22 16:41:55 --> Security Class Initialized
DEBUG - 2025-05-22 16:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:41:55 --> Input Class Initialized
INFO - 2025-05-22 16:41:55 --> Language Class Initialized
INFO - 2025-05-22 16:41:55 --> Loader Class Initialized
INFO - 2025-05-22 16:41:55 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:41:55 --> Controller Class Initialized
DEBUG - 2025-05-22 16:41:55 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-22 16:41:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-22 16:41:55 --> Helper loaded: inflector_helper
INFO - 2025-05-22 16:41:55 --> Email Class Initialized
INFO - 2025-05-22 16:41:55 --> Final output sent to browser
DEBUG - 2025-05-22 16:41:55 --> Total execution time: 0.0329
ERROR - 2025-05-22 16:48:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:48:28 --> Config Class Initialized
INFO - 2025-05-22 16:48:28 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:48:28 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:48:28 --> Utf8 Class Initialized
INFO - 2025-05-22 16:48:28 --> URI Class Initialized
INFO - 2025-05-22 16:48:28 --> Router Class Initialized
INFO - 2025-05-22 16:48:28 --> Output Class Initialized
INFO - 2025-05-22 16:48:28 --> Security Class Initialized
DEBUG - 2025-05-22 16:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:48:28 --> Input Class Initialized
INFO - 2025-05-22 16:48:28 --> Language Class Initialized
ERROR - 2025-05-22 16:48:28 --> Severity: error --> Exception: Class "Restserver\Libraries\RestController" not found C:\wamp64\www\event_app\application\controllers\api\Auth.php 7
ERROR - 2025-05-22 16:49:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:49:58 --> Config Class Initialized
INFO - 2025-05-22 16:49:58 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:49:58 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:49:58 --> Utf8 Class Initialized
INFO - 2025-05-22 16:49:58 --> URI Class Initialized
INFO - 2025-05-22 16:49:58 --> Router Class Initialized
INFO - 2025-05-22 16:49:58 --> Output Class Initialized
INFO - 2025-05-22 16:49:58 --> Security Class Initialized
DEBUG - 2025-05-22 16:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:49:58 --> Input Class Initialized
INFO - 2025-05-22 16:49:58 --> Language Class Initialized
ERROR - 2025-05-22 16:49:58 --> Severity: error --> Exception: Class "Restserver\Libraries\RestController" not found C:\wamp64\www\event_app\application\controllers\api\Auth.php 7
ERROR - 2025-05-22 16:50:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:50:35 --> Config Class Initialized
INFO - 2025-05-22 16:50:35 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:50:35 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:50:35 --> Utf8 Class Initialized
INFO - 2025-05-22 16:50:35 --> URI Class Initialized
INFO - 2025-05-22 16:50:35 --> Router Class Initialized
INFO - 2025-05-22 16:50:35 --> Output Class Initialized
INFO - 2025-05-22 16:50:35 --> Security Class Initialized
DEBUG - 2025-05-22 16:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:50:35 --> Input Class Initialized
INFO - 2025-05-22 16:50:35 --> Language Class Initialized
ERROR - 2025-05-22 16:50:35 --> Severity: error --> Exception: Class "Restserver\Libraries\RestController" not found C:\wamp64\www\event_app\application\controllers\api\Auth.php 7
ERROR - 2025-05-22 16:52:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:52:29 --> Config Class Initialized
INFO - 2025-05-22 16:52:29 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:52:29 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:52:29 --> Utf8 Class Initialized
INFO - 2025-05-22 16:52:29 --> URI Class Initialized
INFO - 2025-05-22 16:52:29 --> Router Class Initialized
INFO - 2025-05-22 16:52:29 --> Output Class Initialized
INFO - 2025-05-22 16:52:29 --> Security Class Initialized
DEBUG - 2025-05-22 16:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:52:29 --> Input Class Initialized
INFO - 2025-05-22 16:52:29 --> Language Class Initialized
INFO - 2025-05-22 16:52:29 --> Loader Class Initialized
INFO - 2025-05-22 16:52:29 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:52:29 --> Controller Class Initialized
DEBUG - 2025-05-22 16:52:29 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-22 16:52:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-22 16:52:29 --> Helper loaded: inflector_helper
INFO - 2025-05-22 16:52:29 --> Email Class Initialized
DEBUG - 2025-05-22 16:52:29 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
INFO - 2025-05-22 16:52:29 --> Final output sent to browser
DEBUG - 2025-05-22 16:52:29 --> Total execution time: 0.0491
ERROR - 2025-05-22 16:52:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:52:39 --> Config Class Initialized
INFO - 2025-05-22 16:52:39 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:52:39 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:52:39 --> Utf8 Class Initialized
INFO - 2025-05-22 16:52:39 --> URI Class Initialized
INFO - 2025-05-22 16:52:39 --> Router Class Initialized
INFO - 2025-05-22 16:52:39 --> Output Class Initialized
INFO - 2025-05-22 16:52:39 --> Security Class Initialized
DEBUG - 2025-05-22 16:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:52:39 --> Input Class Initialized
INFO - 2025-05-22 16:52:39 --> Language Class Initialized
INFO - 2025-05-22 16:52:39 --> Loader Class Initialized
INFO - 2025-05-22 16:52:39 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:52:39 --> Controller Class Initialized
DEBUG - 2025-05-22 16:52:39 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-22 16:52:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-22 16:52:39 --> Helper loaded: inflector_helper
INFO - 2025-05-22 16:52:39 --> Email Class Initialized
DEBUG - 2025-05-22 16:52:39 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
INFO - 2025-05-22 16:52:40 --> Language file loaded: language/english/email_lang.php
INFO - 2025-05-22 16:52:43 --> Final output sent to browser
DEBUG - 2025-05-22 16:52:43 --> Total execution time: 4.1958
ERROR - 2025-05-22 16:54:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:54:00 --> Config Class Initialized
INFO - 2025-05-22 16:54:00 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:54:00 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:54:00 --> Utf8 Class Initialized
INFO - 2025-05-22 16:54:00 --> URI Class Initialized
INFO - 2025-05-22 16:54:00 --> Router Class Initialized
INFO - 2025-05-22 16:54:00 --> Output Class Initialized
INFO - 2025-05-22 16:54:00 --> Security Class Initialized
DEBUG - 2025-05-22 16:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:54:00 --> Input Class Initialized
INFO - 2025-05-22 16:54:00 --> Language Class Initialized
INFO - 2025-05-22 16:54:00 --> Loader Class Initialized
INFO - 2025-05-22 16:54:00 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:54:00 --> Controller Class Initialized
DEBUG - 2025-05-22 16:54:00 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-22 16:54:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-22 16:54:00 --> Helper loaded: inflector_helper
INFO - 2025-05-22 16:54:00 --> Email Class Initialized
DEBUG - 2025-05-22 16:54:00 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
INFO - 2025-05-22 16:54:00 --> Final output sent to browser
DEBUG - 2025-05-22 16:54:00 --> Total execution time: 0.0314
ERROR - 2025-05-22 16:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:54:46 --> Config Class Initialized
INFO - 2025-05-22 16:54:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:54:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:54:46 --> Utf8 Class Initialized
INFO - 2025-05-22 16:54:46 --> URI Class Initialized
INFO - 2025-05-22 16:54:46 --> Router Class Initialized
INFO - 2025-05-22 16:54:46 --> Output Class Initialized
INFO - 2025-05-22 16:54:46 --> Security Class Initialized
DEBUG - 2025-05-22 16:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:54:46 --> Input Class Initialized
INFO - 2025-05-22 16:54:46 --> Language Class Initialized
INFO - 2025-05-22 16:54:46 --> Loader Class Initialized
INFO - 2025-05-22 16:54:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:54:46 --> Controller Class Initialized
DEBUG - 2025-05-22 16:54:46 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-22 16:54:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-22 16:54:46 --> Helper loaded: inflector_helper
INFO - 2025-05-22 16:54:46 --> Email Class Initialized
DEBUG - 2025-05-22 16:54:46 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
INFO - 2025-05-22 16:54:46 --> Final output sent to browser
DEBUG - 2025-05-22 16:54:46 --> Total execution time: 0.0355
ERROR - 2025-05-22 16:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-22 16:55:01 --> Config Class Initialized
INFO - 2025-05-22 16:55:01 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:55:01 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:55:01 --> Utf8 Class Initialized
INFO - 2025-05-22 16:55:01 --> URI Class Initialized
INFO - 2025-05-22 16:55:01 --> Router Class Initialized
INFO - 2025-05-22 16:55:01 --> Output Class Initialized
INFO - 2025-05-22 16:55:01 --> Security Class Initialized
DEBUG - 2025-05-22 16:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:55:01 --> Input Class Initialized
INFO - 2025-05-22 16:55:01 --> Language Class Initialized
INFO - 2025-05-22 16:55:01 --> Loader Class Initialized
INFO - 2025-05-22 16:55:01 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:55:01 --> Controller Class Initialized
DEBUG - 2025-05-22 16:55:01 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-22 16:55:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-22 16:55:01 --> Helper loaded: inflector_helper
INFO - 2025-05-22 16:55:01 --> Email Class Initialized
DEBUG - 2025-05-22 16:55:01 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
INFO - 2025-05-22 16:55:01 --> Final output sent to browser
DEBUG - 2025-05-22 16:55:01 --> Total execution time: 0.1254
