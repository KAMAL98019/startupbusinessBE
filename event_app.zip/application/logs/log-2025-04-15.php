<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-04-15 18:12:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-04-15 18:12:38 --> Config Class Initialized
INFO - 2025-04-15 18:12:38 --> Hooks Class Initialized
DEBUG - 2025-04-15 18:12:39 --> UTF-8 Support Enabled
INFO - 2025-04-15 18:12:39 --> Utf8 Class Initialized
INFO - 2025-04-15 18:12:39 --> URI Class Initialized
INFO - 2025-04-15 18:12:39 --> Router Class Initialized
INFO - 2025-04-15 18:12:40 --> Output Class Initialized
INFO - 2025-04-15 18:12:40 --> Security Class Initialized
DEBUG - 2025-04-15 18:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 18:12:41 --> Input Class Initialized
INFO - 2025-04-15 18:12:41 --> Language Class Initialized
INFO - 2025-04-15 18:12:42 --> Loader Class Initialized
INFO - 2025-04-15 18:12:43 --> Database Driver Class Initialized
INFO - 2025-04-15 18:12:43 --> Controller Class Initialized
DEBUG - 2025-04-15 18:12:43 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-04-15 18:12:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-04-15 18:12:43 --> Helper loaded: inflector_helper
INFO - 2025-04-15 18:12:44 --> Final output sent to browser
DEBUG - 2025-04-15 18:12:44 --> Total execution time: 6.4872
ERROR - 2025-04-15 18:27:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-04-15 18:27:39 --> Config Class Initialized
INFO - 2025-04-15 18:27:39 --> Hooks Class Initialized
DEBUG - 2025-04-15 18:27:39 --> UTF-8 Support Enabled
INFO - 2025-04-15 18:27:39 --> Utf8 Class Initialized
INFO - 2025-04-15 18:27:39 --> URI Class Initialized
INFO - 2025-04-15 18:27:39 --> Router Class Initialized
INFO - 2025-04-15 18:27:39 --> Output Class Initialized
INFO - 2025-04-15 18:27:39 --> Security Class Initialized
DEBUG - 2025-04-15 18:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 18:27:39 --> Input Class Initialized
INFO - 2025-04-15 18:27:39 --> Language Class Initialized
ERROR - 2025-04-15 18:27:39 --> Severity: error --> Exception: syntax error, unexpected identifier "o", expecting ")" C:\wamp64\www\event_app\application\controllers\api\login.php 59
ERROR - 2025-04-15 18:27:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-04-15 18:27:58 --> Config Class Initialized
INFO - 2025-04-15 18:27:58 --> Hooks Class Initialized
DEBUG - 2025-04-15 18:27:58 --> UTF-8 Support Enabled
INFO - 2025-04-15 18:27:58 --> Utf8 Class Initialized
INFO - 2025-04-15 18:27:58 --> URI Class Initialized
INFO - 2025-04-15 18:27:58 --> Router Class Initialized
INFO - 2025-04-15 18:27:58 --> Output Class Initialized
INFO - 2025-04-15 18:27:58 --> Security Class Initialized
DEBUG - 2025-04-15 18:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 18:27:58 --> Input Class Initialized
INFO - 2025-04-15 18:27:58 --> Language Class Initialized
ERROR - 2025-04-15 18:27:58 --> Severity: error --> Exception: syntax error, unexpected identifier "o", expecting ")" C:\wamp64\www\event_app\application\controllers\api\login.php 59
ERROR - 2025-04-15 18:28:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-04-15 18:28:45 --> Config Class Initialized
INFO - 2025-04-15 18:28:45 --> Hooks Class Initialized
DEBUG - 2025-04-15 18:28:45 --> UTF-8 Support Enabled
INFO - 2025-04-15 18:28:45 --> Utf8 Class Initialized
INFO - 2025-04-15 18:28:45 --> URI Class Initialized
INFO - 2025-04-15 18:28:45 --> Router Class Initialized
INFO - 2025-04-15 18:28:45 --> Output Class Initialized
INFO - 2025-04-15 18:28:45 --> Security Class Initialized
DEBUG - 2025-04-15 18:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 18:28:45 --> Input Class Initialized
INFO - 2025-04-15 18:28:45 --> Language Class Initialized
ERROR - 2025-04-15 18:28:45 --> Severity: error --> Exception: syntax error, unexpected identifier "o", expecting ")" C:\wamp64\www\event_app\application\controllers\api\login.php 59
ERROR - 2025-04-15 18:29:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-04-15 18:29:19 --> Config Class Initialized
INFO - 2025-04-15 18:29:19 --> Hooks Class Initialized
DEBUG - 2025-04-15 18:29:19 --> UTF-8 Support Enabled
INFO - 2025-04-15 18:29:19 --> Utf8 Class Initialized
INFO - 2025-04-15 18:29:19 --> URI Class Initialized
INFO - 2025-04-15 18:29:19 --> Router Class Initialized
INFO - 2025-04-15 18:29:19 --> Output Class Initialized
INFO - 2025-04-15 18:29:19 --> Security Class Initialized
DEBUG - 2025-04-15 18:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-15 18:29:19 --> Input Class Initialized
INFO - 2025-04-15 18:29:19 --> Language Class Initialized
INFO - 2025-04-15 18:29:19 --> Loader Class Initialized
INFO - 2025-04-15 18:29:19 --> Database Driver Class Initialized
INFO - 2025-04-15 18:29:19 --> Controller Class Initialized
DEBUG - 2025-04-15 18:29:19 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-04-15 18:29:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-04-15 18:29:19 --> Helper loaded: inflector_helper
INFO - 2025-04-15 18:29:20 --> Final output sent to browser
DEBUG - 2025-04-15 18:29:20 --> Total execution time: 0.9066
