<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-05-24 16:42:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-24 16:42:26 --> Config Class Initialized
INFO - 2025-05-24 16:42:26 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:26 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:26 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:26 --> URI Class Initialized
INFO - 2025-05-24 16:42:26 --> Router Class Initialized
INFO - 2025-05-24 16:42:26 --> Output Class Initialized
INFO - 2025-05-24 16:42:26 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:26 --> Input Class Initialized
INFO - 2025-05-24 16:42:26 --> Language Class Initialized
INFO - 2025-05-24 16:42:26 --> Loader Class Initialized
INFO - 2025-05-24 16:42:26 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:26 --> Controller Class Initialized
INFO - 2025-05-24 16:42:26 --> Model "Profile_model" initialized
INFO - 2025-05-24 16:42:26 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:26 --> Helper loaded: security_helper
INFO - 2025-05-24 16:42:26 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:26 --> Total execution time: 0.1333
ERROR - 2025-05-24 16:43:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-24 16:43:03 --> Config Class Initialized
INFO - 2025-05-24 16:43:03 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:43:03 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:43:03 --> Utf8 Class Initialized
INFO - 2025-05-24 16:43:03 --> URI Class Initialized
INFO - 2025-05-24 16:43:03 --> Router Class Initialized
INFO - 2025-05-24 16:43:03 --> Output Class Initialized
INFO - 2025-05-24 16:43:03 --> Security Class Initialized
DEBUG - 2025-05-24 16:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:43:03 --> Input Class Initialized
INFO - 2025-05-24 16:43:03 --> Language Class Initialized
INFO - 2025-05-24 16:43:03 --> Loader Class Initialized
INFO - 2025-05-24 16:43:03 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:43:03 --> Controller Class Initialized
INFO - 2025-05-24 16:43:03 --> Model "Profile_model" initialized
INFO - 2025-05-24 16:43:03 --> Helper loaded: url_helper
INFO - 2025-05-24 16:43:03 --> Helper loaded: security_helper
INFO - 2025-05-24 16:43:03 --> Final output sent to browser
DEBUG - 2025-05-24 16:43:03 --> Total execution time: 0.0344
