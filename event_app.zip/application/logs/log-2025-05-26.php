<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-05-26 16:42:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-26 16:42:38 --> Config Class Initialized
INFO - 2025-05-26 16:42:38 --> Hooks Class Initialized
DEBUG - 2025-05-26 16:42:38 --> UTF-8 Support Enabled
INFO - 2025-05-26 16:42:38 --> Utf8 Class Initialized
INFO - 2025-05-26 16:42:38 --> URI Class Initialized
INFO - 2025-05-26 16:42:38 --> Router Class Initialized
INFO - 2025-05-26 16:42:38 --> Output Class Initialized
INFO - 2025-05-26 16:42:38 --> Security Class Initialized
DEBUG - 2025-05-26 16:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-26 16:42:38 --> Input Class Initialized
INFO - 2025-05-26 16:42:38 --> Language Class Initialized
INFO - 2025-05-26 16:42:38 --> Loader Class Initialized
INFO - 2025-05-26 16:42:38 --> Database Driver Class Initialized
DEBUG - 2025-05-26 16:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-26 16:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-26 16:42:38 --> Controller Class Initialized
ERROR - 2025-05-26 16:44:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-26 16:44:57 --> Config Class Initialized
INFO - 2025-05-26 16:44:57 --> Hooks Class Initialized
DEBUG - 2025-05-26 16:44:57 --> UTF-8 Support Enabled
INFO - 2025-05-26 16:44:57 --> Utf8 Class Initialized
INFO - 2025-05-26 16:44:57 --> URI Class Initialized
INFO - 2025-05-26 16:44:57 --> Router Class Initialized
INFO - 2025-05-26 16:44:57 --> Output Class Initialized
INFO - 2025-05-26 16:44:57 --> Security Class Initialized
DEBUG - 2025-05-26 16:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-26 16:44:57 --> Input Class Initialized
INFO - 2025-05-26 16:44:57 --> Language Class Initialized
INFO - 2025-05-26 16:44:57 --> Loader Class Initialized
INFO - 2025-05-26 16:44:57 --> Database Driver Class Initialized
DEBUG - 2025-05-26 16:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-26 16:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-26 16:44:57 --> Controller Class Initialized
DEBUG - 2025-05-26 16:44:57 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-26 16:44:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-26 16:44:57 --> Helper loaded: inflector_helper
INFO - 2025-05-26 16:44:57 --> Email Class Initialized
DEBUG - 2025-05-26 16:44:57 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
ERROR - 2025-05-26 16:45:08 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: No such host is known.  C:\wamp64\www\event_app\system\libraries\Email.php 2070
ERROR - 2025-05-26 16:45:08 --> Severity: Warning --> fsockopen(): Unable to connect to ssl://smtp.gmail.com:465 (php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: No such host is known. ) C:\wamp64\www\event_app\system\libraries\Email.php 2070
INFO - 2025-05-26 16:45:08 --> Language file loaded: language/english/email_lang.php
INFO - 2025-05-26 16:45:08 --> Final output sent to browser
DEBUG - 2025-05-26 16:45:08 --> Total execution time: 11.4501
ERROR - 2025-05-26 17:00:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-26 17:00:08 --> Config Class Initialized
INFO - 2025-05-26 17:00:08 --> Hooks Class Initialized
DEBUG - 2025-05-26 17:00:08 --> UTF-8 Support Enabled
INFO - 2025-05-26 17:00:08 --> Utf8 Class Initialized
INFO - 2025-05-26 17:00:08 --> URI Class Initialized
INFO - 2025-05-26 17:00:08 --> Router Class Initialized
INFO - 2025-05-26 17:00:08 --> Output Class Initialized
INFO - 2025-05-26 17:00:08 --> Security Class Initialized
DEBUG - 2025-05-26 17:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-26 17:00:08 --> Input Class Initialized
INFO - 2025-05-26 17:00:08 --> Language Class Initialized
INFO - 2025-05-26 17:00:08 --> Loader Class Initialized
INFO - 2025-05-26 17:00:08 --> Database Driver Class Initialized
DEBUG - 2025-05-26 17:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-26 17:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-26 17:00:08 --> Controller Class Initialized
DEBUG - 2025-05-26 17:00:08 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-26 17:00:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-26 17:00:08 --> Helper loaded: inflector_helper
INFO - 2025-05-26 17:00:08 --> Email Class Initialized
DEBUG - 2025-05-26 17:00:08 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
ERROR - 2025-05-26 17:00:13 --> Severity: Warning --> fsockopen(): Unable to connect to smtp.gmail.com:587 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond) C:\wamp64\www\event_app\system\libraries\Email.php 2070
INFO - 2025-05-26 17:00:13 --> Language file loaded: language/english/email_lang.php
INFO - 2025-05-26 17:00:13 --> Final output sent to browser
DEBUG - 2025-05-26 17:00:13 --> Total execution time: 5.1891
ERROR - 2025-05-26 17:02:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-26 17:02:10 --> Config Class Initialized
INFO - 2025-05-26 17:02:10 --> Hooks Class Initialized
DEBUG - 2025-05-26 17:02:10 --> UTF-8 Support Enabled
INFO - 2025-05-26 17:02:10 --> Utf8 Class Initialized
INFO - 2025-05-26 17:02:10 --> URI Class Initialized
INFO - 2025-05-26 17:02:10 --> Router Class Initialized
INFO - 2025-05-26 17:02:10 --> Output Class Initialized
INFO - 2025-05-26 17:02:10 --> Security Class Initialized
DEBUG - 2025-05-26 17:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-26 17:02:10 --> Input Class Initialized
INFO - 2025-05-26 17:02:10 --> Language Class Initialized
INFO - 2025-05-26 17:02:10 --> Loader Class Initialized
INFO - 2025-05-26 17:02:10 --> Database Driver Class Initialized
DEBUG - 2025-05-26 17:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-26 17:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-26 17:02:10 --> Controller Class Initialized
DEBUG - 2025-05-26 17:02:10 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-26 17:02:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-26 17:02:10 --> Helper loaded: inflector_helper
INFO - 2025-05-26 17:02:10 --> Email Class Initialized
DEBUG - 2025-05-26 17:02:10 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
DEBUG - 2025-05-26 17:02:10 --> Email class already loaded. Second attempt ignored.
INFO - 2025-05-26 17:02:11 --> Language file loaded: language/english/email_lang.php
INFO - 2025-05-26 17:02:16 --> Final output sent to browser
DEBUG - 2025-05-26 17:02:16 --> Total execution time: 5.7551
ERROR - 2025-05-26 17:06:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-26 17:06:53 --> Config Class Initialized
INFO - 2025-05-26 17:06:53 --> Hooks Class Initialized
DEBUG - 2025-05-26 17:06:53 --> UTF-8 Support Enabled
INFO - 2025-05-26 17:06:53 --> Utf8 Class Initialized
INFO - 2025-05-26 17:06:53 --> URI Class Initialized
INFO - 2025-05-26 17:06:53 --> Router Class Initialized
INFO - 2025-05-26 17:06:53 --> Output Class Initialized
INFO - 2025-05-26 17:06:53 --> Security Class Initialized
DEBUG - 2025-05-26 17:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-26 17:06:53 --> Input Class Initialized
INFO - 2025-05-26 17:06:53 --> Language Class Initialized
INFO - 2025-05-26 17:06:53 --> Loader Class Initialized
INFO - 2025-05-26 17:06:53 --> Database Driver Class Initialized
DEBUG - 2025-05-26 17:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-26 17:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-26 17:06:53 --> Controller Class Initialized
DEBUG - 2025-05-26 17:06:53 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-26 17:06:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-26 17:06:53 --> Helper loaded: inflector_helper
INFO - 2025-05-26 17:06:53 --> Email Class Initialized
DEBUG - 2025-05-26 17:06:53 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
INFO - 2025-05-26 17:06:53 --> Final output sent to browser
DEBUG - 2025-05-26 17:06:53 --> Total execution time: 0.0387
ERROR - 2025-05-26 17:08:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-26 17:08:18 --> Config Class Initialized
INFO - 2025-05-26 17:08:18 --> Hooks Class Initialized
DEBUG - 2025-05-26 17:08:18 --> UTF-8 Support Enabled
INFO - 2025-05-26 17:08:18 --> Utf8 Class Initialized
INFO - 2025-05-26 17:08:18 --> URI Class Initialized
INFO - 2025-05-26 17:08:18 --> Router Class Initialized
INFO - 2025-05-26 17:08:18 --> Output Class Initialized
INFO - 2025-05-26 17:08:18 --> Security Class Initialized
DEBUG - 2025-05-26 17:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-26 17:08:18 --> Input Class Initialized
INFO - 2025-05-26 17:08:18 --> Language Class Initialized
INFO - 2025-05-26 17:08:18 --> Loader Class Initialized
INFO - 2025-05-26 17:08:18 --> Database Driver Class Initialized
DEBUG - 2025-05-26 17:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-26 17:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-26 17:08:18 --> Controller Class Initialized
DEBUG - 2025-05-26 17:08:18 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-26 17:08:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-26 17:08:18 --> Helper loaded: inflector_helper
INFO - 2025-05-26 17:08:18 --> Email Class Initialized
DEBUG - 2025-05-26 17:08:18 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
DEBUG - 2025-05-26 17:08:18 --> Email class already loaded. Second attempt ignored.
INFO - 2025-05-26 17:08:18 --> Language file loaded: language/english/email_lang.php
INFO - 2025-05-26 17:08:22 --> Final output sent to browser
DEBUG - 2025-05-26 17:08:22 --> Total execution time: 3.9031
ERROR - 2025-05-26 17:14:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-26 17:14:30 --> Config Class Initialized
INFO - 2025-05-26 17:14:30 --> Hooks Class Initialized
DEBUG - 2025-05-26 17:14:30 --> UTF-8 Support Enabled
INFO - 2025-05-26 17:14:30 --> Utf8 Class Initialized
INFO - 2025-05-26 17:14:30 --> URI Class Initialized
INFO - 2025-05-26 17:14:30 --> Router Class Initialized
INFO - 2025-05-26 17:14:30 --> Output Class Initialized
INFO - 2025-05-26 17:14:30 --> Security Class Initialized
DEBUG - 2025-05-26 17:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-26 17:14:30 --> Input Class Initialized
INFO - 2025-05-26 17:14:30 --> Language Class Initialized
INFO - 2025-05-26 17:14:30 --> Loader Class Initialized
INFO - 2025-05-26 17:14:30 --> Database Driver Class Initialized
DEBUG - 2025-05-26 17:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-26 17:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-26 17:14:30 --> Controller Class Initialized
DEBUG - 2025-05-26 17:14:30 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-26 17:14:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-26 17:14:30 --> Helper loaded: inflector_helper
INFO - 2025-05-26 17:14:30 --> Email Class Initialized
DEBUG - 2025-05-26 17:14:30 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
DEBUG - 2025-05-26 17:14:30 --> Email class already loaded. Second attempt ignored.
INFO - 2025-05-26 17:14:30 --> Language file loaded: language/english/email_lang.php
INFO - 2025-05-26 17:14:34 --> Final output sent to browser
DEBUG - 2025-05-26 17:14:34 --> Total execution time: 3.8505
ERROR - 2025-05-26 17:15:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-26 17:15:20 --> Config Class Initialized
INFO - 2025-05-26 17:15:20 --> Hooks Class Initialized
DEBUG - 2025-05-26 17:15:20 --> UTF-8 Support Enabled
INFO - 2025-05-26 17:15:20 --> Utf8 Class Initialized
INFO - 2025-05-26 17:15:20 --> URI Class Initialized
INFO - 2025-05-26 17:15:20 --> Router Class Initialized
INFO - 2025-05-26 17:15:20 --> Output Class Initialized
INFO - 2025-05-26 17:15:20 --> Security Class Initialized
DEBUG - 2025-05-26 17:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-26 17:15:20 --> Input Class Initialized
INFO - 2025-05-26 17:15:20 --> Language Class Initialized
INFO - 2025-05-26 17:15:20 --> Loader Class Initialized
INFO - 2025-05-26 17:15:20 --> Database Driver Class Initialized
DEBUG - 2025-05-26 17:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-26 17:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-26 17:15:20 --> Controller Class Initialized
DEBUG - 2025-05-26 17:15:20 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-26 17:15:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-26 17:15:20 --> Helper loaded: inflector_helper
INFO - 2025-05-26 17:15:20 --> Email Class Initialized
DEBUG - 2025-05-26 17:15:20 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
INFO - 2025-05-26 17:15:20 --> Final output sent to browser
DEBUG - 2025-05-26 17:15:20 --> Total execution time: 0.1506
ERROR - 2025-05-26 17:16:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-26 17:16:45 --> Config Class Initialized
INFO - 2025-05-26 17:16:45 --> Hooks Class Initialized
DEBUG - 2025-05-26 17:16:45 --> UTF-8 Support Enabled
INFO - 2025-05-26 17:16:45 --> Utf8 Class Initialized
INFO - 2025-05-26 17:16:45 --> URI Class Initialized
INFO - 2025-05-26 17:16:45 --> Router Class Initialized
INFO - 2025-05-26 17:16:45 --> Output Class Initialized
INFO - 2025-05-26 17:16:45 --> Security Class Initialized
DEBUG - 2025-05-26 17:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-26 17:16:45 --> Input Class Initialized
INFO - 2025-05-26 17:16:45 --> Language Class Initialized
INFO - 2025-05-26 17:16:45 --> Loader Class Initialized
INFO - 2025-05-26 17:16:45 --> Database Driver Class Initialized
DEBUG - 2025-05-26 17:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-26 17:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-26 17:16:45 --> Controller Class Initialized
DEBUG - 2025-05-26 17:16:45 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-26 17:16:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-26 17:16:45 --> Helper loaded: inflector_helper
INFO - 2025-05-26 17:16:45 --> Email Class Initialized
DEBUG - 2025-05-26 17:16:45 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
INFO - 2025-05-26 17:16:45 --> Final output sent to browser
DEBUG - 2025-05-26 17:16:45 --> Total execution time: 0.0368
ERROR - 2025-05-26 17:38:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-26 17:38:22 --> Config Class Initialized
INFO - 2025-05-26 17:38:22 --> Hooks Class Initialized
DEBUG - 2025-05-26 17:38:22 --> UTF-8 Support Enabled
INFO - 2025-05-26 17:38:22 --> Utf8 Class Initialized
INFO - 2025-05-26 17:38:22 --> URI Class Initialized
INFO - 2025-05-26 17:38:22 --> Router Class Initialized
INFO - 2025-05-26 17:38:22 --> Output Class Initialized
INFO - 2025-05-26 17:38:22 --> Security Class Initialized
DEBUG - 2025-05-26 17:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-26 17:38:22 --> Input Class Initialized
INFO - 2025-05-26 17:38:22 --> Language Class Initialized
INFO - 2025-05-26 17:38:22 --> Loader Class Initialized
INFO - 2025-05-26 17:38:22 --> Database Driver Class Initialized
DEBUG - 2025-05-26 17:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-26 17:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-26 17:38:22 --> Controller Class Initialized
DEBUG - 2025-05-26 17:38:22 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-26 17:38:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-26 17:38:22 --> Helper loaded: inflector_helper
INFO - 2025-05-26 17:38:22 --> Email Class Initialized
DEBUG - 2025-05-26 17:38:22 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
INFO - 2025-05-26 17:38:22 --> Final output sent to browser
DEBUG - 2025-05-26 17:38:22 --> Total execution time: 0.0568
