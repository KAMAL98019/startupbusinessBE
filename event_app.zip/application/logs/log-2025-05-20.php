<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-05-20 16:20:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:20:41 --> Config Class Initialized
INFO - 2025-05-20 16:20:41 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:20:41 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:20:41 --> Utf8 Class Initialized
INFO - 2025-05-20 16:20:41 --> URI Class Initialized
DEBUG - 2025-05-20 16:20:41 --> No URI present. Default controller set.
INFO - 2025-05-20 16:20:41 --> Router Class Initialized
INFO - 2025-05-20 16:20:41 --> Output Class Initialized
INFO - 2025-05-20 16:20:41 --> Security Class Initialized
DEBUG - 2025-05-20 16:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:20:41 --> Input Class Initialized
INFO - 2025-05-20 16:20:42 --> Language Class Initialized
INFO - 2025-05-20 16:20:42 --> Loader Class Initialized
INFO - 2025-05-20 16:20:42 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:20:42 --> Controller Class Initialized
INFO - 2025-05-20 16:20:42 --> File loaded: C:\wamp64\www\event_app\application\views\welcome_message.php
INFO - 2025-05-20 16:20:42 --> Final output sent to browser
DEBUG - 2025-05-20 16:20:42 --> Total execution time: 1.2104
ERROR - 2025-05-20 16:27:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:27:02 --> Config Class Initialized
INFO - 2025-05-20 16:27:02 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:27:02 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:27:02 --> Utf8 Class Initialized
INFO - 2025-05-20 16:27:02 --> URI Class Initialized
INFO - 2025-05-20 16:27:02 --> Router Class Initialized
INFO - 2025-05-20 16:27:02 --> Output Class Initialized
INFO - 2025-05-20 16:27:02 --> Security Class Initialized
DEBUG - 2025-05-20 16:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:27:02 --> Input Class Initialized
INFO - 2025-05-20 16:27:02 --> Language Class Initialized
ERROR - 2025-05-20 16:27:02 --> Severity: Warning --> require(C:\wamp64\www\event_app\application\libraries/REST_Controller.php): Failed to open stream: No such file or directory C:\wamp64\www\event_app\application\controllers\api\ForgetPasswordController.php 4
ERROR - 2025-05-20 16:27:02 --> Severity: error --> Exception: Failed opening required 'C:\wamp64\www\event_app\application\libraries/REST_Controller.php' (include_path='.;C:\php\pear') C:\wamp64\www\event_app\application\controllers\api\ForgetPasswordController.php 4
ERROR - 2025-05-20 16:27:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:27:26 --> Config Class Initialized
INFO - 2025-05-20 16:27:26 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:27:26 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:27:26 --> Utf8 Class Initialized
INFO - 2025-05-20 16:27:26 --> URI Class Initialized
INFO - 2025-05-20 16:27:26 --> Router Class Initialized
INFO - 2025-05-20 16:27:26 --> Output Class Initialized
INFO - 2025-05-20 16:27:26 --> Security Class Initialized
DEBUG - 2025-05-20 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:27:26 --> Input Class Initialized
INFO - 2025-05-20 16:27:26 --> Language Class Initialized
ERROR - 2025-05-20 16:27:26 --> Severity: Warning --> require(C:\wamp64\www\event_app\application\libraries/REST_Controller.php): Failed to open stream: No such file or directory C:\wamp64\www\event_app\application\controllers\api\ForgetPasswordController.php 4
ERROR - 2025-05-20 16:27:26 --> Severity: error --> Exception: Failed opening required 'C:\wamp64\www\event_app\application\libraries/REST_Controller.php' (include_path='.;C:\php\pear') C:\wamp64\www\event_app\application\controllers\api\ForgetPasswordController.php 4
ERROR - 2025-05-20 16:28:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:28:14 --> Config Class Initialized
INFO - 2025-05-20 16:28:14 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:28:14 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:28:14 --> Utf8 Class Initialized
INFO - 2025-05-20 16:28:14 --> URI Class Initialized
INFO - 2025-05-20 16:28:14 --> Router Class Initialized
INFO - 2025-05-20 16:28:14 --> Output Class Initialized
INFO - 2025-05-20 16:28:14 --> Security Class Initialized
DEBUG - 2025-05-20 16:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:28:14 --> Input Class Initialized
INFO - 2025-05-20 16:28:14 --> Language Class Initialized
ERROR - 2025-05-20 16:28:14 --> Severity: Warning --> require(C:\wamp64\www\event_app\application\libraries/REST_Controller.php): Failed to open stream: No such file or directory C:\wamp64\www\event_app\application\controllers\api\ForgetPasswordController.php 4
ERROR - 2025-05-20 16:28:14 --> Severity: error --> Exception: Failed opening required 'C:\wamp64\www\event_app\application\libraries/REST_Controller.php' (include_path='.;C:\php\pear') C:\wamp64\www\event_app\application\controllers\api\ForgetPasswordController.php 4
ERROR - 2025-05-20 16:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:31:12 --> Config Class Initialized
INFO - 2025-05-20 16:31:12 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:31:12 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:31:12 --> Utf8 Class Initialized
INFO - 2025-05-20 16:31:12 --> URI Class Initialized
INFO - 2025-05-20 16:31:12 --> Router Class Initialized
INFO - 2025-05-20 16:31:12 --> Output Class Initialized
INFO - 2025-05-20 16:31:12 --> Security Class Initialized
DEBUG - 2025-05-20 16:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:31:12 --> Input Class Initialized
INFO - 2025-05-20 16:31:12 --> Language Class Initialized
ERROR - 2025-05-20 16:31:12 --> Severity: error --> Exception: Class "Restserver\Libraries\RestController" not found C:\wamp64\www\event_app\application\controllers\api\ForgetPasswordController.php 7
ERROR - 2025-05-20 16:32:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:32:35 --> Config Class Initialized
INFO - 2025-05-20 16:32:35 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:32:35 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:32:35 --> Utf8 Class Initialized
INFO - 2025-05-20 16:32:35 --> URI Class Initialized
INFO - 2025-05-20 16:32:35 --> Router Class Initialized
INFO - 2025-05-20 16:32:35 --> Output Class Initialized
INFO - 2025-05-20 16:32:35 --> Security Class Initialized
DEBUG - 2025-05-20 16:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:32:35 --> Input Class Initialized
INFO - 2025-05-20 16:32:35 --> Language Class Initialized
ERROR - 2025-05-20 16:32:35 --> Severity: error --> Exception: Class "Restserver\Libraries\RestController" not found C:\wamp64\www\event_app\application\controllers\api\ForgetPasswordController.php 7
ERROR - 2025-05-20 16:34:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:34:35 --> Config Class Initialized
INFO - 2025-05-20 16:34:35 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:34:35 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:34:35 --> Utf8 Class Initialized
INFO - 2025-05-20 16:34:35 --> URI Class Initialized
INFO - 2025-05-20 16:34:35 --> Router Class Initialized
INFO - 2025-05-20 16:34:35 --> Output Class Initialized
INFO - 2025-05-20 16:34:35 --> Security Class Initialized
DEBUG - 2025-05-20 16:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:34:35 --> Input Class Initialized
INFO - 2025-05-20 16:34:35 --> Language Class Initialized
ERROR - 2025-05-20 16:34:35 --> Severity: error --> Exception: Class "Restserver\Libraries\RestController" not found C:\wamp64\www\event_app\application\controllers\api\ForgetPasswordController.php 7
ERROR - 2025-05-20 16:35:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:35:30 --> Config Class Initialized
INFO - 2025-05-20 16:35:30 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:35:30 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:35:30 --> Utf8 Class Initialized
INFO - 2025-05-20 16:35:30 --> URI Class Initialized
INFO - 2025-05-20 16:35:30 --> Router Class Initialized
INFO - 2025-05-20 16:35:30 --> Output Class Initialized
INFO - 2025-05-20 16:35:30 --> Security Class Initialized
DEBUG - 2025-05-20 16:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:35:30 --> Input Class Initialized
INFO - 2025-05-20 16:35:30 --> Language Class Initialized
INFO - 2025-05-20 16:35:30 --> Loader Class Initialized
INFO - 2025-05-20 16:35:30 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:35:30 --> Controller Class Initialized
DEBUG - 2025-05-20 16:35:30 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:35:31 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2025-05-20 16:35:31 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\wamp64\www\event_app\application\libraries\RestController.php 835
INFO - 2025-05-20 16:35:31 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:35:31 --> Email Class Initialized
INFO - 2025-05-20 16:35:31 --> Final output sent to browser
DEBUG - 2025-05-20 16:35:31 --> Total execution time: 0.2607
ERROR - 2025-05-20 16:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:37:46 --> Config Class Initialized
INFO - 2025-05-20 16:37:46 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:37:46 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:37:46 --> Utf8 Class Initialized
INFO - 2025-05-20 16:37:46 --> URI Class Initialized
INFO - 2025-05-20 16:37:46 --> Router Class Initialized
INFO - 2025-05-20 16:37:46 --> Output Class Initialized
INFO - 2025-05-20 16:37:46 --> Security Class Initialized
DEBUG - 2025-05-20 16:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:37:46 --> Input Class Initialized
INFO - 2025-05-20 16:37:46 --> Language Class Initialized
INFO - 2025-05-20 16:37:46 --> Loader Class Initialized
INFO - 2025-05-20 16:37:46 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:37:46 --> Controller Class Initialized
DEBUG - 2025-05-20 16:37:46 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:37:46 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2025-05-20 16:37:46 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\wamp64\www\event_app\application\libraries\RestController.php 835
INFO - 2025-05-20 16:37:46 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:37:46 --> Email Class Initialized
INFO - 2025-05-20 16:37:46 --> Final output sent to browser
DEBUG - 2025-05-20 16:37:46 --> Total execution time: 0.0314
ERROR - 2025-05-20 16:40:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:40:08 --> Config Class Initialized
INFO - 2025-05-20 16:40:08 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:40:08 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:40:08 --> Utf8 Class Initialized
INFO - 2025-05-20 16:40:08 --> URI Class Initialized
INFO - 2025-05-20 16:40:08 --> Router Class Initialized
INFO - 2025-05-20 16:40:08 --> Output Class Initialized
INFO - 2025-05-20 16:40:08 --> Security Class Initialized
DEBUG - 2025-05-20 16:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:40:08 --> Input Class Initialized
INFO - 2025-05-20 16:40:08 --> Language Class Initialized
INFO - 2025-05-20 16:40:08 --> Loader Class Initialized
INFO - 2025-05-20 16:40:08 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:40:08 --> Controller Class Initialized
DEBUG - 2025-05-20 16:40:08 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:40:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 16:40:08 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:40:08 --> Email Class Initialized
INFO - 2025-05-20 16:40:08 --> Final output sent to browser
DEBUG - 2025-05-20 16:40:08 --> Total execution time: 0.1972
ERROR - 2025-05-20 16:41:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:41:18 --> Config Class Initialized
INFO - 2025-05-20 16:41:18 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:41:18 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:41:18 --> Utf8 Class Initialized
INFO - 2025-05-20 16:41:18 --> URI Class Initialized
INFO - 2025-05-20 16:41:18 --> Router Class Initialized
INFO - 2025-05-20 16:41:18 --> Output Class Initialized
INFO - 2025-05-20 16:41:18 --> Security Class Initialized
DEBUG - 2025-05-20 16:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:41:18 --> Input Class Initialized
INFO - 2025-05-20 16:41:18 --> Language Class Initialized
INFO - 2025-05-20 16:41:18 --> Loader Class Initialized
INFO - 2025-05-20 16:41:18 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:41:18 --> Controller Class Initialized
DEBUG - 2025-05-20 16:41:18 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:41:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 16:41:18 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:41:18 --> Email Class Initialized
INFO - 2025-05-20 16:41:18 --> Final output sent to browser
DEBUG - 2025-05-20 16:41:18 --> Total execution time: 0.1183
ERROR - 2025-05-20 16:42:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:42:56 --> Config Class Initialized
INFO - 2025-05-20 16:42:56 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:42:56 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:42:56 --> Utf8 Class Initialized
INFO - 2025-05-20 16:42:56 --> URI Class Initialized
INFO - 2025-05-20 16:42:56 --> Router Class Initialized
INFO - 2025-05-20 16:42:56 --> Output Class Initialized
INFO - 2025-05-20 16:42:56 --> Security Class Initialized
DEBUG - 2025-05-20 16:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:42:56 --> Input Class Initialized
INFO - 2025-05-20 16:42:56 --> Language Class Initialized
INFO - 2025-05-20 16:42:56 --> Loader Class Initialized
INFO - 2025-05-20 16:42:56 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:42:56 --> Controller Class Initialized
DEBUG - 2025-05-20 16:42:56 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:42:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 16:42:56 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:42:56 --> Email Class Initialized
INFO - 2025-05-20 16:42:56 --> Final output sent to browser
DEBUG - 2025-05-20 16:42:56 --> Total execution time: 0.0330
ERROR - 2025-05-20 16:46:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:46:55 --> Config Class Initialized
INFO - 2025-05-20 16:46:55 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:46:55 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:46:55 --> Utf8 Class Initialized
INFO - 2025-05-20 16:46:55 --> URI Class Initialized
INFO - 2025-05-20 16:46:55 --> Router Class Initialized
INFO - 2025-05-20 16:46:55 --> Output Class Initialized
INFO - 2025-05-20 16:46:55 --> Security Class Initialized
DEBUG - 2025-05-20 16:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:46:55 --> Input Class Initialized
INFO - 2025-05-20 16:46:55 --> Language Class Initialized
INFO - 2025-05-20 16:46:55 --> Loader Class Initialized
INFO - 2025-05-20 16:46:55 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:46:55 --> Controller Class Initialized
DEBUG - 2025-05-20 16:46:55 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:46:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 16:46:55 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:46:55 --> Email Class Initialized
INFO - 2025-05-20 16:46:55 --> Final output sent to browser
DEBUG - 2025-05-20 16:46:55 --> Total execution time: 0.0431
ERROR - 2025-05-20 16:46:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:46:58 --> Config Class Initialized
INFO - 2025-05-20 16:46:58 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:46:58 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:46:58 --> Utf8 Class Initialized
INFO - 2025-05-20 16:46:58 --> URI Class Initialized
INFO - 2025-05-20 16:46:58 --> Router Class Initialized
INFO - 2025-05-20 16:46:58 --> Output Class Initialized
INFO - 2025-05-20 16:46:58 --> Security Class Initialized
DEBUG - 2025-05-20 16:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:46:58 --> Input Class Initialized
INFO - 2025-05-20 16:46:58 --> Language Class Initialized
INFO - 2025-05-20 16:46:58 --> Loader Class Initialized
INFO - 2025-05-20 16:46:58 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:46:58 --> Controller Class Initialized
DEBUG - 2025-05-20 16:46:58 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:46:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 16:46:58 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:46:58 --> Email Class Initialized
INFO - 2025-05-20 16:46:58 --> Final output sent to browser
DEBUG - 2025-05-20 16:46:58 --> Total execution time: 0.0271
ERROR - 2025-05-20 16:47:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:47:31 --> Config Class Initialized
INFO - 2025-05-20 16:47:31 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:47:31 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:47:31 --> Utf8 Class Initialized
INFO - 2025-05-20 16:47:31 --> URI Class Initialized
INFO - 2025-05-20 16:47:31 --> Router Class Initialized
INFO - 2025-05-20 16:47:31 --> Output Class Initialized
INFO - 2025-05-20 16:47:31 --> Security Class Initialized
DEBUG - 2025-05-20 16:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:47:31 --> Input Class Initialized
INFO - 2025-05-20 16:47:31 --> Language Class Initialized
INFO - 2025-05-20 16:47:31 --> Loader Class Initialized
INFO - 2025-05-20 16:47:31 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:47:31 --> Controller Class Initialized
DEBUG - 2025-05-20 16:47:31 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:47:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 16:47:31 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:47:31 --> Email Class Initialized
INFO - 2025-05-20 16:47:31 --> Final output sent to browser
DEBUG - 2025-05-20 16:47:31 --> Total execution time: 0.0490
ERROR - 2025-05-20 16:47:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:47:59 --> Config Class Initialized
INFO - 2025-05-20 16:47:59 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:47:59 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:47:59 --> Utf8 Class Initialized
INFO - 2025-05-20 16:47:59 --> URI Class Initialized
INFO - 2025-05-20 16:47:59 --> Router Class Initialized
INFO - 2025-05-20 16:47:59 --> Output Class Initialized
INFO - 2025-05-20 16:47:59 --> Security Class Initialized
DEBUG - 2025-05-20 16:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:47:59 --> Input Class Initialized
INFO - 2025-05-20 16:47:59 --> Language Class Initialized
INFO - 2025-05-20 16:47:59 --> Loader Class Initialized
INFO - 2025-05-20 16:47:59 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:47:59 --> Controller Class Initialized
DEBUG - 2025-05-20 16:47:59 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:47:59 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2025-05-20 16:47:59 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\wamp64\www\event_app\application\libraries\RestController.php 835
INFO - 2025-05-20 16:47:59 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:47:59 --> Email Class Initialized
INFO - 2025-05-20 16:47:59 --> Final output sent to browser
DEBUG - 2025-05-20 16:47:59 --> Total execution time: 0.1009
ERROR - 2025-05-20 16:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:51:45 --> Config Class Initialized
INFO - 2025-05-20 16:51:45 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:51:45 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:51:45 --> Utf8 Class Initialized
INFO - 2025-05-20 16:51:45 --> URI Class Initialized
INFO - 2025-05-20 16:51:45 --> Router Class Initialized
INFO - 2025-05-20 16:51:45 --> Output Class Initialized
INFO - 2025-05-20 16:51:45 --> Security Class Initialized
DEBUG - 2025-05-20 16:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:51:45 --> Input Class Initialized
INFO - 2025-05-20 16:51:45 --> Language Class Initialized
INFO - 2025-05-20 16:51:45 --> Loader Class Initialized
INFO - 2025-05-20 16:51:45 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:51:45 --> Controller Class Initialized
DEBUG - 2025-05-20 16:51:45 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:51:45 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2025-05-20 16:51:45 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\wamp64\www\event_app\application\libraries\RestController.php 835
INFO - 2025-05-20 16:51:45 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:51:45 --> Email Class Initialized
INFO - 2025-05-20 16:51:45 --> Final output sent to browser
DEBUG - 2025-05-20 16:51:45 --> Total execution time: 0.0309
ERROR - 2025-05-20 16:55:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:55:38 --> Config Class Initialized
INFO - 2025-05-20 16:55:38 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:55:38 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:55:38 --> Utf8 Class Initialized
INFO - 2025-05-20 16:55:38 --> URI Class Initialized
INFO - 2025-05-20 16:55:38 --> Router Class Initialized
INFO - 2025-05-20 16:55:38 --> Output Class Initialized
INFO - 2025-05-20 16:55:38 --> Security Class Initialized
DEBUG - 2025-05-20 16:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:55:38 --> Input Class Initialized
INFO - 2025-05-20 16:55:38 --> Language Class Initialized
INFO - 2025-05-20 16:55:38 --> Loader Class Initialized
INFO - 2025-05-20 16:55:38 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:55:38 --> Controller Class Initialized
DEBUG - 2025-05-20 16:55:38 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:55:38 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2025-05-20 16:55:38 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\wamp64\www\event_app\application\libraries\RestController.php 835
INFO - 2025-05-20 16:55:38 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:55:38 --> Email Class Initialized
INFO - 2025-05-20 16:55:38 --> Final output sent to browser
DEBUG - 2025-05-20 16:55:38 --> Total execution time: 0.0300
ERROR - 2025-05-20 16:58:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 16:58:48 --> Config Class Initialized
INFO - 2025-05-20 16:58:48 --> Hooks Class Initialized
DEBUG - 2025-05-20 16:58:48 --> UTF-8 Support Enabled
INFO - 2025-05-20 16:58:48 --> Utf8 Class Initialized
INFO - 2025-05-20 16:58:48 --> URI Class Initialized
INFO - 2025-05-20 16:58:48 --> Router Class Initialized
INFO - 2025-05-20 16:58:48 --> Output Class Initialized
INFO - 2025-05-20 16:58:48 --> Security Class Initialized
DEBUG - 2025-05-20 16:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 16:58:48 --> Input Class Initialized
INFO - 2025-05-20 16:58:48 --> Language Class Initialized
INFO - 2025-05-20 16:58:48 --> Loader Class Initialized
INFO - 2025-05-20 16:58:48 --> Database Driver Class Initialized
DEBUG - 2025-05-20 16:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 16:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 16:58:48 --> Controller Class Initialized
DEBUG - 2025-05-20 16:58:48 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 16:58:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 16:58:48 --> Helper loaded: inflector_helper
INFO - 2025-05-20 16:58:48 --> Email Class Initialized
INFO - 2025-05-20 16:58:48 --> Final output sent to browser
DEBUG - 2025-05-20 16:58:48 --> Total execution time: 0.0592
ERROR - 2025-05-20 17:04:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:04:44 --> Config Class Initialized
INFO - 2025-05-20 17:04:44 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:04:44 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:04:44 --> Utf8 Class Initialized
INFO - 2025-05-20 17:04:44 --> URI Class Initialized
INFO - 2025-05-20 17:04:44 --> Router Class Initialized
INFO - 2025-05-20 17:04:44 --> Output Class Initialized
INFO - 2025-05-20 17:04:44 --> Security Class Initialized
DEBUG - 2025-05-20 17:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:04:44 --> Input Class Initialized
INFO - 2025-05-20 17:04:44 --> Language Class Initialized
INFO - 2025-05-20 17:04:44 --> Loader Class Initialized
INFO - 2025-05-20 17:04:44 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:04:44 --> Controller Class Initialized
DEBUG - 2025-05-20 17:04:44 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 17:04:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 17:04:44 --> Helper loaded: inflector_helper
INFO - 2025-05-20 17:04:44 --> Email Class Initialized
INFO - 2025-05-20 17:04:44 --> Final output sent to browser
DEBUG - 2025-05-20 17:04:44 --> Total execution time: 0.0321
ERROR - 2025-05-20 17:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:19:42 --> Config Class Initialized
INFO - 2025-05-20 17:19:42 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:19:42 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:19:42 --> Utf8 Class Initialized
INFO - 2025-05-20 17:19:42 --> URI Class Initialized
INFO - 2025-05-20 17:19:42 --> Router Class Initialized
INFO - 2025-05-20 17:19:42 --> Output Class Initialized
INFO - 2025-05-20 17:19:42 --> Security Class Initialized
DEBUG - 2025-05-20 17:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:19:42 --> Input Class Initialized
INFO - 2025-05-20 17:19:42 --> Language Class Initialized
INFO - 2025-05-20 17:19:42 --> Loader Class Initialized
INFO - 2025-05-20 17:19:42 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:19:42 --> Controller Class Initialized
DEBUG - 2025-05-20 17:19:42 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 17:19:42 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2025-05-20 17:19:42 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\wamp64\www\event_app\application\libraries\RestController.php 835
INFO - 2025-05-20 17:19:42 --> Helper loaded: inflector_helper
INFO - 2025-05-20 17:19:42 --> Email Class Initialized
INFO - 2025-05-20 17:19:42 --> Final output sent to browser
DEBUG - 2025-05-20 17:19:42 --> Total execution time: 0.0364
ERROR - 2025-05-20 17:22:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:22:36 --> Config Class Initialized
INFO - 2025-05-20 17:22:36 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:22:36 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:22:36 --> Utf8 Class Initialized
INFO - 2025-05-20 17:22:36 --> URI Class Initialized
INFO - 2025-05-20 17:22:36 --> Router Class Initialized
INFO - 2025-05-20 17:22:36 --> Output Class Initialized
INFO - 2025-05-20 17:22:36 --> Security Class Initialized
DEBUG - 2025-05-20 17:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:22:36 --> Input Class Initialized
INFO - 2025-05-20 17:22:36 --> Language Class Initialized
INFO - 2025-05-20 17:22:36 --> Loader Class Initialized
INFO - 2025-05-20 17:22:36 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:22:36 --> Controller Class Initialized
DEBUG - 2025-05-20 17:22:36 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 17:22:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 17:22:36 --> Helper loaded: inflector_helper
INFO - 2025-05-20 17:22:36 --> Email Class Initialized
INFO - 2025-05-20 17:22:36 --> Final output sent to browser
DEBUG - 2025-05-20 17:22:36 --> Total execution time: 0.0562
ERROR - 2025-05-20 17:27:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:27:59 --> Config Class Initialized
INFO - 2025-05-20 17:27:59 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:27:59 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:27:59 --> Utf8 Class Initialized
INFO - 2025-05-20 17:27:59 --> URI Class Initialized
INFO - 2025-05-20 17:27:59 --> Router Class Initialized
INFO - 2025-05-20 17:27:59 --> Output Class Initialized
INFO - 2025-05-20 17:27:59 --> Security Class Initialized
DEBUG - 2025-05-20 17:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:27:59 --> Input Class Initialized
INFO - 2025-05-20 17:27:59 --> Language Class Initialized
INFO - 2025-05-20 17:27:59 --> Loader Class Initialized
INFO - 2025-05-20 17:27:59 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:27:59 --> Controller Class Initialized
DEBUG - 2025-05-20 17:27:59 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 17:27:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 17:27:59 --> Email Class Initialized
INFO - 2025-05-20 17:27:59 --> Helper loaded: inflector_helper
INFO - 2025-05-20 17:27:59 --> Final output sent to browser
DEBUG - 2025-05-20 17:27:59 --> Total execution time: 0.0436
ERROR - 2025-05-20 17:28:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:28:58 --> Config Class Initialized
INFO - 2025-05-20 17:28:58 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:28:58 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:28:58 --> Utf8 Class Initialized
INFO - 2025-05-20 17:28:58 --> URI Class Initialized
INFO - 2025-05-20 17:28:58 --> Router Class Initialized
INFO - 2025-05-20 17:28:58 --> Output Class Initialized
INFO - 2025-05-20 17:28:58 --> Security Class Initialized
DEBUG - 2025-05-20 17:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:28:58 --> Input Class Initialized
INFO - 2025-05-20 17:28:58 --> Language Class Initialized
INFO - 2025-05-20 17:28:58 --> Loader Class Initialized
INFO - 2025-05-20 17:28:58 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:28:58 --> Controller Class Initialized
ERROR - 2025-05-20 17:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:29:00 --> Config Class Initialized
INFO - 2025-05-20 17:29:00 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:29:00 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:29:00 --> Utf8 Class Initialized
INFO - 2025-05-20 17:29:00 --> URI Class Initialized
INFO - 2025-05-20 17:29:00 --> Router Class Initialized
INFO - 2025-05-20 17:29:00 --> Output Class Initialized
INFO - 2025-05-20 17:29:00 --> Security Class Initialized
DEBUG - 2025-05-20 17:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:29:00 --> Input Class Initialized
INFO - 2025-05-20 17:29:00 --> Language Class Initialized
INFO - 2025-05-20 17:29:00 --> Loader Class Initialized
INFO - 2025-05-20 17:29:00 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:29:00 --> Controller Class Initialized
ERROR - 2025-05-20 17:29:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:29:18 --> Config Class Initialized
INFO - 2025-05-20 17:29:18 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:29:18 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:29:18 --> Utf8 Class Initialized
INFO - 2025-05-20 17:29:18 --> URI Class Initialized
INFO - 2025-05-20 17:29:18 --> Router Class Initialized
INFO - 2025-05-20 17:29:18 --> Output Class Initialized
INFO - 2025-05-20 17:29:18 --> Security Class Initialized
DEBUG - 2025-05-20 17:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:29:18 --> Input Class Initialized
INFO - 2025-05-20 17:29:18 --> Language Class Initialized
INFO - 2025-05-20 17:29:18 --> Loader Class Initialized
INFO - 2025-05-20 17:29:18 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:29:18 --> Controller Class Initialized
ERROR - 2025-05-20 17:31:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:31:28 --> Config Class Initialized
INFO - 2025-05-20 17:31:28 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:31:28 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:31:28 --> Utf8 Class Initialized
INFO - 2025-05-20 17:31:28 --> URI Class Initialized
INFO - 2025-05-20 17:31:28 --> Router Class Initialized
INFO - 2025-05-20 17:31:28 --> Output Class Initialized
INFO - 2025-05-20 17:31:28 --> Security Class Initialized
DEBUG - 2025-05-20 17:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:31:28 --> Input Class Initialized
INFO - 2025-05-20 17:31:28 --> Language Class Initialized
INFO - 2025-05-20 17:31:28 --> Loader Class Initialized
INFO - 2025-05-20 17:31:28 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:31:28 --> Controller Class Initialized
ERROR - 2025-05-20 17:31:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:31:30 --> Config Class Initialized
INFO - 2025-05-20 17:31:30 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:31:30 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:31:30 --> Utf8 Class Initialized
INFO - 2025-05-20 17:31:30 --> URI Class Initialized
INFO - 2025-05-20 17:31:30 --> Router Class Initialized
INFO - 2025-05-20 17:31:30 --> Output Class Initialized
INFO - 2025-05-20 17:31:30 --> Security Class Initialized
DEBUG - 2025-05-20 17:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:31:30 --> Input Class Initialized
INFO - 2025-05-20 17:31:30 --> Language Class Initialized
INFO - 2025-05-20 17:31:30 --> Loader Class Initialized
INFO - 2025-05-20 17:31:30 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:31:30 --> Controller Class Initialized
ERROR - 2025-05-20 17:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:31:56 --> Config Class Initialized
INFO - 2025-05-20 17:31:56 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:31:56 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:31:56 --> Utf8 Class Initialized
INFO - 2025-05-20 17:31:56 --> URI Class Initialized
INFO - 2025-05-20 17:31:56 --> Router Class Initialized
INFO - 2025-05-20 17:31:56 --> Output Class Initialized
INFO - 2025-05-20 17:31:56 --> Security Class Initialized
DEBUG - 2025-05-20 17:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:31:56 --> Input Class Initialized
INFO - 2025-05-20 17:31:56 --> Language Class Initialized
INFO - 2025-05-20 17:31:56 --> Loader Class Initialized
INFO - 2025-05-20 17:31:56 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:31:56 --> Controller Class Initialized
ERROR - 2025-05-20 17:46:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:46:50 --> Config Class Initialized
INFO - 2025-05-20 17:46:50 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:46:51 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:46:51 --> Utf8 Class Initialized
INFO - 2025-05-20 17:46:51 --> URI Class Initialized
DEBUG - 2025-05-20 17:46:51 --> No URI present. Default controller set.
INFO - 2025-05-20 17:46:51 --> Router Class Initialized
INFO - 2025-05-20 17:46:51 --> Output Class Initialized
INFO - 2025-05-20 17:46:51 --> Security Class Initialized
DEBUG - 2025-05-20 17:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:46:51 --> Input Class Initialized
INFO - 2025-05-20 17:46:51 --> Language Class Initialized
INFO - 2025-05-20 17:46:51 --> Loader Class Initialized
INFO - 2025-05-20 17:46:51 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:46:51 --> Controller Class Initialized
INFO - 2025-05-20 17:46:51 --> File loaded: C:\wamp64\www\event_app\application\views\welcome_message.php
INFO - 2025-05-20 17:46:51 --> Final output sent to browser
DEBUG - 2025-05-20 17:46:51 --> Total execution time: 0.0892
ERROR - 2025-05-20 17:46:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:46:53 --> Config Class Initialized
INFO - 2025-05-20 17:46:53 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:46:53 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:46:53 --> Utf8 Class Initialized
INFO - 2025-05-20 17:46:53 --> URI Class Initialized
DEBUG - 2025-05-20 17:46:53 --> No URI present. Default controller set.
INFO - 2025-05-20 17:46:53 --> Router Class Initialized
INFO - 2025-05-20 17:46:53 --> Output Class Initialized
INFO - 2025-05-20 17:46:53 --> Security Class Initialized
DEBUG - 2025-05-20 17:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:46:53 --> Input Class Initialized
INFO - 2025-05-20 17:46:53 --> Language Class Initialized
INFO - 2025-05-20 17:46:53 --> Loader Class Initialized
INFO - 2025-05-20 17:46:53 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:46:53 --> Controller Class Initialized
INFO - 2025-05-20 17:46:53 --> File loaded: C:\wamp64\www\event_app\application\views\welcome_message.php
INFO - 2025-05-20 17:46:53 --> Final output sent to browser
DEBUG - 2025-05-20 17:46:53 --> Total execution time: 0.0246
ERROR - 2025-05-20 17:48:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:48:47 --> Config Class Initialized
INFO - 2025-05-20 17:48:47 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:48:47 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:48:47 --> Utf8 Class Initialized
INFO - 2025-05-20 17:48:47 --> URI Class Initialized
INFO - 2025-05-20 17:48:47 --> Router Class Initialized
INFO - 2025-05-20 17:48:47 --> Output Class Initialized
INFO - 2025-05-20 17:48:47 --> Security Class Initialized
DEBUG - 2025-05-20 17:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:48:47 --> Input Class Initialized
INFO - 2025-05-20 17:48:47 --> Language Class Initialized
INFO - 2025-05-20 17:48:47 --> Loader Class Initialized
INFO - 2025-05-20 17:48:47 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:48:47 --> Controller Class Initialized
DEBUG - 2025-05-20 17:48:47 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 17:48:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 17:48:47 --> Helper loaded: inflector_helper
INFO - 2025-05-20 17:48:47 --> Email Class Initialized
INFO - 2025-05-20 17:48:47 --> Final output sent to browser
DEBUG - 2025-05-20 17:48:47 --> Total execution time: 0.0576
ERROR - 2025-05-20 17:49:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:49:24 --> Config Class Initialized
INFO - 2025-05-20 17:49:24 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:49:24 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:49:24 --> Utf8 Class Initialized
INFO - 2025-05-20 17:49:24 --> URI Class Initialized
DEBUG - 2025-05-20 17:49:24 --> No URI present. Default controller set.
INFO - 2025-05-20 17:49:24 --> Router Class Initialized
INFO - 2025-05-20 17:49:24 --> Output Class Initialized
INFO - 2025-05-20 17:49:24 --> Security Class Initialized
DEBUG - 2025-05-20 17:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:49:24 --> Input Class Initialized
INFO - 2025-05-20 17:49:24 --> Language Class Initialized
INFO - 2025-05-20 17:49:24 --> Loader Class Initialized
INFO - 2025-05-20 17:49:24 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:49:24 --> Controller Class Initialized
INFO - 2025-05-20 17:49:24 --> File loaded: C:\wamp64\www\event_app\application\views\welcome_message.php
INFO - 2025-05-20 17:49:24 --> Final output sent to browser
DEBUG - 2025-05-20 17:49:24 --> Total execution time: 0.0262
ERROR - 2025-05-20 17:49:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:49:47 --> Config Class Initialized
INFO - 2025-05-20 17:49:47 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:49:47 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:49:47 --> Utf8 Class Initialized
INFO - 2025-05-20 17:49:47 --> URI Class Initialized
DEBUG - 2025-05-20 17:49:47 --> No URI present. Default controller set.
INFO - 2025-05-20 17:49:47 --> Router Class Initialized
INFO - 2025-05-20 17:49:47 --> Output Class Initialized
INFO - 2025-05-20 17:49:47 --> Security Class Initialized
DEBUG - 2025-05-20 17:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:49:47 --> Input Class Initialized
INFO - 2025-05-20 17:49:47 --> Language Class Initialized
INFO - 2025-05-20 17:49:47 --> Loader Class Initialized
INFO - 2025-05-20 17:49:47 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:49:47 --> Controller Class Initialized
INFO - 2025-05-20 17:49:47 --> File loaded: C:\wamp64\www\event_app\application\views\welcome_message.php
INFO - 2025-05-20 17:49:47 --> Final output sent to browser
DEBUG - 2025-05-20 17:49:47 --> Total execution time: 0.0426
ERROR - 2025-05-20 17:49:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:49:52 --> Config Class Initialized
INFO - 2025-05-20 17:49:52 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:49:52 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:49:52 --> Utf8 Class Initialized
INFO - 2025-05-20 17:49:52 --> URI Class Initialized
INFO - 2025-05-20 17:49:52 --> Router Class Initialized
INFO - 2025-05-20 17:49:52 --> Output Class Initialized
INFO - 2025-05-20 17:49:52 --> Security Class Initialized
DEBUG - 2025-05-20 17:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:49:52 --> Input Class Initialized
INFO - 2025-05-20 17:49:52 --> Language Class Initialized
INFO - 2025-05-20 17:49:52 --> Loader Class Initialized
INFO - 2025-05-20 17:49:52 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:49:52 --> Controller Class Initialized
ERROR - 2025-05-20 17:50:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:50:07 --> Config Class Initialized
INFO - 2025-05-20 17:50:07 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:50:07 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:50:07 --> Utf8 Class Initialized
INFO - 2025-05-20 17:50:07 --> URI Class Initialized
DEBUG - 2025-05-20 17:50:07 --> No URI present. Default controller set.
INFO - 2025-05-20 17:50:07 --> Router Class Initialized
INFO - 2025-05-20 17:50:07 --> Output Class Initialized
INFO - 2025-05-20 17:50:07 --> Security Class Initialized
DEBUG - 2025-05-20 17:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:50:07 --> Input Class Initialized
INFO - 2025-05-20 17:50:07 --> Language Class Initialized
INFO - 2025-05-20 17:50:07 --> Loader Class Initialized
INFO - 2025-05-20 17:50:07 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:50:07 --> Controller Class Initialized
INFO - 2025-05-20 17:50:07 --> File loaded: C:\wamp64\www\event_app\application\views\welcome_message.php
INFO - 2025-05-20 17:50:07 --> Final output sent to browser
DEBUG - 2025-05-20 17:50:07 --> Total execution time: 0.0284
ERROR - 2025-05-20 17:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:50:10 --> Config Class Initialized
INFO - 2025-05-20 17:50:10 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:50:10 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:50:10 --> Utf8 Class Initialized
INFO - 2025-05-20 17:50:10 --> URI Class Initialized
INFO - 2025-05-20 17:50:10 --> Router Class Initialized
INFO - 2025-05-20 17:50:10 --> Output Class Initialized
INFO - 2025-05-20 17:50:10 --> Security Class Initialized
DEBUG - 2025-05-20 17:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:50:10 --> Input Class Initialized
INFO - 2025-05-20 17:50:10 --> Language Class Initialized
INFO - 2025-05-20 17:50:10 --> Loader Class Initialized
INFO - 2025-05-20 17:50:10 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:50:10 --> Controller Class Initialized
DEBUG - 2025-05-20 17:50:10 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 17:50:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 17:50:10 --> Helper loaded: inflector_helper
INFO - 2025-05-20 17:50:10 --> Email Class Initialized
INFO - 2025-05-20 17:50:10 --> Final output sent to browser
DEBUG - 2025-05-20 17:50:10 --> Total execution time: 0.0281
ERROR - 2025-05-20 17:50:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:50:29 --> Config Class Initialized
INFO - 2025-05-20 17:50:29 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:50:29 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:50:29 --> Utf8 Class Initialized
INFO - 2025-05-20 17:50:29 --> URI Class Initialized
INFO - 2025-05-20 17:50:29 --> Router Class Initialized
INFO - 2025-05-20 17:50:29 --> Output Class Initialized
INFO - 2025-05-20 17:50:29 --> Security Class Initialized
DEBUG - 2025-05-20 17:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:50:29 --> Input Class Initialized
INFO - 2025-05-20 17:50:29 --> Language Class Initialized
INFO - 2025-05-20 17:50:29 --> Loader Class Initialized
INFO - 2025-05-20 17:50:29 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:50:29 --> Controller Class Initialized
DEBUG - 2025-05-20 17:50:29 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 17:50:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 17:50:29 --> Helper loaded: inflector_helper
INFO - 2025-05-20 17:50:29 --> Email Class Initialized
INFO - 2025-05-20 17:50:29 --> Final output sent to browser
DEBUG - 2025-05-20 17:50:29 --> Total execution time: 0.0274
ERROR - 2025-05-20 17:50:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-20 17:50:51 --> Config Class Initialized
INFO - 2025-05-20 17:50:51 --> Hooks Class Initialized
DEBUG - 2025-05-20 17:50:51 --> UTF-8 Support Enabled
INFO - 2025-05-20 17:50:51 --> Utf8 Class Initialized
INFO - 2025-05-20 17:50:51 --> URI Class Initialized
INFO - 2025-05-20 17:50:51 --> Router Class Initialized
INFO - 2025-05-20 17:50:51 --> Output Class Initialized
INFO - 2025-05-20 17:50:51 --> Security Class Initialized
DEBUG - 2025-05-20 17:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-20 17:50:51 --> Input Class Initialized
INFO - 2025-05-20 17:50:51 --> Language Class Initialized
INFO - 2025-05-20 17:50:51 --> Loader Class Initialized
INFO - 2025-05-20 17:50:51 --> Database Driver Class Initialized
DEBUG - 2025-05-20 17:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-20 17:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-20 17:50:51 --> Controller Class Initialized
DEBUG - 2025-05-20 17:50:51 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-20 17:50:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-20 17:50:51 --> Helper loaded: inflector_helper
INFO - 2025-05-20 17:50:51 --> Email Class Initialized
INFO - 2025-05-20 17:50:51 --> Final output sent to browser
DEBUG - 2025-05-20 17:50:51 --> Total execution time: 0.0286
