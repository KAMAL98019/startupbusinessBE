<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-05-28 15:42:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-28 15:42:26 --> Config Class Initialized
INFO - 2025-05-28 15:42:26 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:42:26 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:42:26 --> Utf8 Class Initialized
INFO - 2025-05-28 15:42:26 --> URI Class Initialized
INFO - 2025-05-28 15:42:26 --> Router Class Initialized
INFO - 2025-05-28 15:42:26 --> Output Class Initialized
INFO - 2025-05-28 15:42:26 --> Security Class Initialized
DEBUG - 2025-05-28 15:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:42:26 --> Input Class Initialized
INFO - 2025-05-28 15:42:26 --> Language Class Initialized
INFO - 2025-05-28 15:42:26 --> Loader Class Initialized
INFO - 2025-05-28 15:42:26 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:42:26 --> Controller Class Initialized
DEBUG - 2025-05-28 15:42:26 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-28 15:42:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-28 15:42:26 --> Helper loaded: inflector_helper
INFO - 2025-05-28 15:42:26 --> Email Class Initialized
DEBUG - 2025-05-28 15:42:26 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
INFO - 2025-05-28 15:42:26 --> Final output sent to browser
DEBUG - 2025-05-28 15:42:26 --> Total execution time: 0.0580
ERROR - 2025-05-28 15:42:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-28 15:42:38 --> Config Class Initialized
INFO - 2025-05-28 15:42:38 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:42:38 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:42:38 --> Utf8 Class Initialized
INFO - 2025-05-28 15:42:38 --> URI Class Initialized
INFO - 2025-05-28 15:42:38 --> Router Class Initialized
INFO - 2025-05-28 15:42:38 --> Output Class Initialized
INFO - 2025-05-28 15:42:38 --> Security Class Initialized
DEBUG - 2025-05-28 15:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:42:38 --> Input Class Initialized
INFO - 2025-05-28 15:42:38 --> Language Class Initialized
INFO - 2025-05-28 15:42:38 --> Loader Class Initialized
INFO - 2025-05-28 15:42:38 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:42:38 --> Controller Class Initialized
DEBUG - 2025-05-28 15:42:38 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-28 15:42:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-28 15:42:38 --> Helper loaded: inflector_helper
INFO - 2025-05-28 15:42:38 --> Email Class Initialized
DEBUG - 2025-05-28 15:42:38 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
DEBUG - 2025-05-28 15:42:38 --> Email class already loaded. Second attempt ignored.
ERROR - 2025-05-28 15:42:43 --> Severity: Warning --> fsockopen(): Unable to connect to smtp.gmail.com:587 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond) C:\wamp64\www\event_app\system\libraries\Email.php 2070
INFO - 2025-05-28 15:42:43 --> Language file loaded: language/english/email_lang.php
INFO - 2025-05-28 15:42:43 --> Final output sent to browser
DEBUG - 2025-05-28 15:42:43 --> Total execution time: 5.0969
ERROR - 2025-05-28 15:44:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-28 15:44:37 --> Config Class Initialized
INFO - 2025-05-28 15:44:37 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:44:37 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:44:37 --> Utf8 Class Initialized
INFO - 2025-05-28 15:44:37 --> URI Class Initialized
INFO - 2025-05-28 15:44:37 --> Router Class Initialized
INFO - 2025-05-28 15:44:37 --> Output Class Initialized
INFO - 2025-05-28 15:44:37 --> Security Class Initialized
DEBUG - 2025-05-28 15:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:44:37 --> Input Class Initialized
INFO - 2025-05-28 15:44:37 --> Language Class Initialized
INFO - 2025-05-28 15:44:37 --> Loader Class Initialized
INFO - 2025-05-28 15:44:37 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:44:37 --> Controller Class Initialized
DEBUG - 2025-05-28 15:44:37 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-28 15:44:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-28 15:44:37 --> Helper loaded: inflector_helper
INFO - 2025-05-28 15:44:37 --> Email Class Initialized
DEBUG - 2025-05-28 15:44:37 --> Config file loaded: C:\wamp64\www\event_app\application\config/email.php
DEBUG - 2025-05-28 15:44:37 --> Email class already loaded. Second attempt ignored.
INFO - 2025-05-28 15:44:38 --> Language file loaded: language/english/email_lang.php
INFO - 2025-05-28 15:44:43 --> Final output sent to browser
DEBUG - 2025-05-28 15:44:43 --> Total execution time: 5.6787
ERROR - 2025-05-28 17:30:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-28 17:30:48 --> Config Class Initialized
INFO - 2025-05-28 17:30:48 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:30:48 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:30:48 --> Utf8 Class Initialized
INFO - 2025-05-28 17:30:48 --> URI Class Initialized
INFO - 2025-05-28 17:30:48 --> Router Class Initialized
INFO - 2025-05-28 17:30:48 --> Output Class Initialized
INFO - 2025-05-28 17:30:48 --> Security Class Initialized
DEBUG - 2025-05-28 17:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:30:48 --> Input Class Initialized
INFO - 2025-05-28 17:30:48 --> Language Class Initialized
INFO - 2025-05-28 17:30:48 --> Loader Class Initialized
INFO - 2025-05-28 17:30:48 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:30:48 --> Controller Class Initialized
DEBUG - 2025-05-28 17:30:48 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-28 17:30:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-28 17:30:48 --> Helper loaded: inflector_helper
INFO - 2025-05-28 17:30:48 --> Final output sent to browser
DEBUG - 2025-05-28 17:30:48 --> Total execution time: 0.1601
ERROR - 2025-05-28 17:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-28 17:32:30 --> Config Class Initialized
INFO - 2025-05-28 17:32:30 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:32:30 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:32:30 --> Utf8 Class Initialized
INFO - 2025-05-28 17:32:30 --> URI Class Initialized
INFO - 2025-05-28 17:32:30 --> Router Class Initialized
INFO - 2025-05-28 17:32:30 --> Output Class Initialized
INFO - 2025-05-28 17:32:30 --> Security Class Initialized
DEBUG - 2025-05-28 17:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:32:30 --> Input Class Initialized
INFO - 2025-05-28 17:32:30 --> Language Class Initialized
INFO - 2025-05-28 17:32:30 --> Loader Class Initialized
INFO - 2025-05-28 17:32:30 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:32:30 --> Controller Class Initialized
DEBUG - 2025-05-28 17:32:30 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-28 17:32:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-28 17:32:30 --> Helper loaded: inflector_helper
INFO - 2025-05-28 17:32:30 --> Final output sent to browser
DEBUG - 2025-05-28 17:32:30 --> Total execution time: 0.1864
ERROR - 2025-05-28 17:32:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-28 17:32:32 --> Config Class Initialized
INFO - 2025-05-28 17:32:32 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:32:32 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:32:32 --> Utf8 Class Initialized
INFO - 2025-05-28 17:32:32 --> URI Class Initialized
INFO - 2025-05-28 17:32:32 --> Router Class Initialized
INFO - 2025-05-28 17:32:32 --> Output Class Initialized
INFO - 2025-05-28 17:32:32 --> Security Class Initialized
DEBUG - 2025-05-28 17:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:32:32 --> Input Class Initialized
INFO - 2025-05-28 17:32:32 --> Language Class Initialized
INFO - 2025-05-28 17:32:32 --> Loader Class Initialized
INFO - 2025-05-28 17:32:32 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:32:32 --> Controller Class Initialized
DEBUG - 2025-05-28 17:32:32 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-28 17:32:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-28 17:32:32 --> Helper loaded: inflector_helper
INFO - 2025-05-28 17:32:32 --> Final output sent to browser
DEBUG - 2025-05-28 17:32:32 --> Total execution time: 0.1312
ERROR - 2025-05-28 17:32:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-28 17:32:38 --> Config Class Initialized
INFO - 2025-05-28 17:32:38 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:32:38 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:32:38 --> Utf8 Class Initialized
INFO - 2025-05-28 17:32:38 --> URI Class Initialized
INFO - 2025-05-28 17:32:38 --> Router Class Initialized
INFO - 2025-05-28 17:32:38 --> Output Class Initialized
INFO - 2025-05-28 17:32:38 --> Security Class Initialized
DEBUG - 2025-05-28 17:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:32:38 --> Input Class Initialized
INFO - 2025-05-28 17:32:38 --> Language Class Initialized
INFO - 2025-05-28 17:32:38 --> Loader Class Initialized
INFO - 2025-05-28 17:32:38 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:32:38 --> Controller Class Initialized
DEBUG - 2025-05-28 17:32:38 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-28 17:32:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-28 17:32:38 --> Helper loaded: inflector_helper
INFO - 2025-05-28 17:32:38 --> Final output sent to browser
DEBUG - 2025-05-28 17:32:38 --> Total execution time: 0.1152
ERROR - 2025-05-28 17:32:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-28 17:32:47 --> Config Class Initialized
INFO - 2025-05-28 17:32:47 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:32:47 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:32:47 --> Utf8 Class Initialized
INFO - 2025-05-28 17:32:47 --> URI Class Initialized
INFO - 2025-05-28 17:32:47 --> Router Class Initialized
INFO - 2025-05-28 17:32:47 --> Output Class Initialized
INFO - 2025-05-28 17:32:47 --> Security Class Initialized
DEBUG - 2025-05-28 17:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:32:47 --> Input Class Initialized
INFO - 2025-05-28 17:32:47 --> Language Class Initialized
INFO - 2025-05-28 17:32:47 --> Loader Class Initialized
INFO - 2025-05-28 17:32:47 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:32:47 --> Controller Class Initialized
DEBUG - 2025-05-28 17:32:47 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-28 17:32:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-28 17:32:47 --> Helper loaded: inflector_helper
INFO - 2025-05-28 17:32:47 --> Final output sent to browser
DEBUG - 2025-05-28 17:32:47 --> Total execution time: 0.1130
