<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-05-23 16:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 16:28:59 --> Config Class Initialized
INFO - 2025-05-23 16:28:59 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:28:59 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:28:59 --> Utf8 Class Initialized
INFO - 2025-05-23 16:28:59 --> URI Class Initialized
INFO - 2025-05-23 16:28:59 --> Router Class Initialized
INFO - 2025-05-23 16:28:59 --> Output Class Initialized
INFO - 2025-05-23 16:28:59 --> Security Class Initialized
DEBUG - 2025-05-23 16:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:28:59 --> Input Class Initialized
INFO - 2025-05-23 16:28:59 --> Language Class Initialized
INFO - 2025-05-23 16:28:59 --> Loader Class Initialized
INFO - 2025-05-23 16:28:59 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:28:59 --> Controller Class Initialized
INFO - 2025-05-23 16:28:59 --> Model "Profile_model" initialized
INFO - 2025-05-23 16:28:59 --> Helper loaded: url_helper
INFO - 2025-05-23 16:28:59 --> Final output sent to browser
DEBUG - 2025-05-23 16:28:59 --> Total execution time: 0.0628
ERROR - 2025-05-23 16:32:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 16:32:15 --> Config Class Initialized
INFO - 2025-05-23 16:32:15 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:32:15 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:32:15 --> Utf8 Class Initialized
INFO - 2025-05-23 16:32:15 --> URI Class Initialized
DEBUG - 2025-05-23 16:32:15 --> No URI present. Default controller set.
INFO - 2025-05-23 16:32:15 --> Router Class Initialized
INFO - 2025-05-23 16:32:15 --> Output Class Initialized
INFO - 2025-05-23 16:32:15 --> Security Class Initialized
DEBUG - 2025-05-23 16:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:32:15 --> Input Class Initialized
INFO - 2025-05-23 16:32:15 --> Language Class Initialized
INFO - 2025-05-23 16:32:15 --> Loader Class Initialized
INFO - 2025-05-23 16:32:15 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:32:15 --> Controller Class Initialized
INFO - 2025-05-23 16:32:15 --> File loaded: C:\wamp64\www\event_app\application\views\welcome_message.php
INFO - 2025-05-23 16:32:15 --> Final output sent to browser
DEBUG - 2025-05-23 16:32:15 --> Total execution time: 0.0325
ERROR - 2025-05-23 16:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 16:59:59 --> Config Class Initialized
INFO - 2025-05-23 16:59:59 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:59:59 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:59:59 --> Utf8 Class Initialized
INFO - 2025-05-23 16:59:59 --> URI Class Initialized
INFO - 2025-05-23 16:59:59 --> Router Class Initialized
INFO - 2025-05-23 16:59:59 --> Output Class Initialized
INFO - 2025-05-23 16:59:59 --> Security Class Initialized
DEBUG - 2025-05-23 16:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:59:59 --> Input Class Initialized
INFO - 2025-05-23 16:59:59 --> Language Class Initialized
INFO - 2025-05-23 16:59:59 --> Loader Class Initialized
INFO - 2025-05-23 16:59:59 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:59:59 --> Controller Class Initialized
ERROR - 2025-05-23 17:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:02:43 --> Config Class Initialized
INFO - 2025-05-23 17:02:43 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:02:43 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:02:43 --> Utf8 Class Initialized
INFO - 2025-05-23 17:02:43 --> URI Class Initialized
INFO - 2025-05-23 17:02:43 --> Router Class Initialized
INFO - 2025-05-23 17:02:43 --> Output Class Initialized
INFO - 2025-05-23 17:02:43 --> Security Class Initialized
DEBUG - 2025-05-23 17:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:02:43 --> Input Class Initialized
INFO - 2025-05-23 17:02:43 --> Language Class Initialized
INFO - 2025-05-23 17:02:43 --> Loader Class Initialized
INFO - 2025-05-23 17:02:43 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:02:43 --> Controller Class Initialized
ERROR - 2025-05-23 17:02:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:02:57 --> Config Class Initialized
INFO - 2025-05-23 17:02:57 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:02:57 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:02:57 --> Utf8 Class Initialized
INFO - 2025-05-23 17:02:57 --> URI Class Initialized
INFO - 2025-05-23 17:02:57 --> Router Class Initialized
INFO - 2025-05-23 17:02:57 --> Output Class Initialized
INFO - 2025-05-23 17:02:57 --> Security Class Initialized
DEBUG - 2025-05-23 17:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:02:57 --> Input Class Initialized
INFO - 2025-05-23 17:02:57 --> Language Class Initialized
INFO - 2025-05-23 17:02:57 --> Loader Class Initialized
INFO - 2025-05-23 17:02:57 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:02:57 --> Controller Class Initialized
ERROR - 2025-05-23 17:05:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:05:02 --> Config Class Initialized
INFO - 2025-05-23 17:05:02 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:05:02 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:05:02 --> Utf8 Class Initialized
INFO - 2025-05-23 17:05:02 --> URI Class Initialized
INFO - 2025-05-23 17:05:02 --> Router Class Initialized
INFO - 2025-05-23 17:05:02 --> Output Class Initialized
INFO - 2025-05-23 17:05:02 --> Security Class Initialized
DEBUG - 2025-05-23 17:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:05:02 --> Input Class Initialized
INFO - 2025-05-23 17:05:02 --> Language Class Initialized
INFO - 2025-05-23 17:05:02 --> Loader Class Initialized
INFO - 2025-05-23 17:05:02 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:05:02 --> Controller Class Initialized
ERROR - 2025-05-23 17:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:06:44 --> Config Class Initialized
INFO - 2025-05-23 17:06:44 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:06:44 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:06:44 --> Utf8 Class Initialized
INFO - 2025-05-23 17:06:44 --> URI Class Initialized
INFO - 2025-05-23 17:06:44 --> Router Class Initialized
INFO - 2025-05-23 17:06:44 --> Output Class Initialized
INFO - 2025-05-23 17:06:44 --> Security Class Initialized
DEBUG - 2025-05-23 17:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:06:44 --> Input Class Initialized
INFO - 2025-05-23 17:06:44 --> Language Class Initialized
INFO - 2025-05-23 17:06:44 --> Loader Class Initialized
INFO - 2025-05-23 17:06:44 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:06:44 --> Controller Class Initialized
ERROR - 2025-05-23 17:07:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:07:02 --> Config Class Initialized
INFO - 2025-05-23 17:07:02 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:07:02 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:07:02 --> Utf8 Class Initialized
INFO - 2025-05-23 17:07:02 --> URI Class Initialized
INFO - 2025-05-23 17:07:02 --> Router Class Initialized
INFO - 2025-05-23 17:07:02 --> Output Class Initialized
INFO - 2025-05-23 17:07:02 --> Security Class Initialized
DEBUG - 2025-05-23 17:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:07:02 --> Input Class Initialized
INFO - 2025-05-23 17:07:02 --> Language Class Initialized
INFO - 2025-05-23 17:07:02 --> Loader Class Initialized
INFO - 2025-05-23 17:07:02 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:07:02 --> Controller Class Initialized
ERROR - 2025-05-23 17:22:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:22:30 --> Config Class Initialized
INFO - 2025-05-23 17:22:30 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:22:30 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:22:30 --> Utf8 Class Initialized
INFO - 2025-05-23 17:22:30 --> URI Class Initialized
INFO - 2025-05-23 17:22:30 --> Router Class Initialized
INFO - 2025-05-23 17:22:30 --> Output Class Initialized
INFO - 2025-05-23 17:22:30 --> Security Class Initialized
DEBUG - 2025-05-23 17:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:22:30 --> Input Class Initialized
INFO - 2025-05-23 17:22:30 --> Language Class Initialized
INFO - 2025-05-23 17:22:30 --> Loader Class Initialized
INFO - 2025-05-23 17:22:30 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:22:30 --> Controller Class Initialized
DEBUG - 2025-05-23 17:22:30 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 17:22:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 17:22:30 --> Helper loaded: inflector_helper
INFO - 2025-05-23 17:22:30 --> Model "Profile_model" initialized
INFO - 2025-05-23 17:22:30 --> Final output sent to browser
DEBUG - 2025-05-23 17:22:30 --> Total execution time: 0.0944
ERROR - 2025-05-23 17:22:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:22:54 --> Config Class Initialized
INFO - 2025-05-23 17:22:54 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:22:54 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:22:54 --> Utf8 Class Initialized
INFO - 2025-05-23 17:22:54 --> URI Class Initialized
INFO - 2025-05-23 17:22:54 --> Router Class Initialized
INFO - 2025-05-23 17:22:54 --> Output Class Initialized
INFO - 2025-05-23 17:22:54 --> Security Class Initialized
DEBUG - 2025-05-23 17:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:22:54 --> Input Class Initialized
INFO - 2025-05-23 17:22:54 --> Language Class Initialized
INFO - 2025-05-23 17:22:54 --> Loader Class Initialized
INFO - 2025-05-23 17:22:54 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:22:54 --> Controller Class Initialized
DEBUG - 2025-05-23 17:22:54 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 17:22:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 17:22:54 --> Helper loaded: inflector_helper
INFO - 2025-05-23 17:22:54 --> Model "Profile_model" initialized
INFO - 2025-05-23 17:22:54 --> Final output sent to browser
DEBUG - 2025-05-23 17:22:54 --> Total execution time: 0.0304
ERROR - 2025-05-23 17:26:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:26:19 --> Config Class Initialized
INFO - 2025-05-23 17:26:19 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:26:19 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:26:19 --> Utf8 Class Initialized
INFO - 2025-05-23 17:26:19 --> URI Class Initialized
INFO - 2025-05-23 17:26:19 --> Router Class Initialized
INFO - 2025-05-23 17:26:19 --> Output Class Initialized
INFO - 2025-05-23 17:26:19 --> Security Class Initialized
DEBUG - 2025-05-23 17:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:26:19 --> Input Class Initialized
INFO - 2025-05-23 17:26:19 --> Language Class Initialized
INFO - 2025-05-23 17:26:19 --> Loader Class Initialized
INFO - 2025-05-23 17:26:19 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:26:19 --> Controller Class Initialized
DEBUG - 2025-05-23 17:26:19 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 17:26:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 17:26:19 --> Helper loaded: inflector_helper
INFO - 2025-05-23 17:26:19 --> Model "Profile_model" initialized
INFO - 2025-05-23 17:26:19 --> Final output sent to browser
DEBUG - 2025-05-23 17:26:19 --> Total execution time: 0.0987
ERROR - 2025-05-23 17:26:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:26:29 --> Config Class Initialized
INFO - 2025-05-23 17:26:29 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:26:29 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:26:29 --> Utf8 Class Initialized
INFO - 2025-05-23 17:26:29 --> URI Class Initialized
INFO - 2025-05-23 17:26:29 --> Router Class Initialized
INFO - 2025-05-23 17:26:29 --> Output Class Initialized
INFO - 2025-05-23 17:26:29 --> Security Class Initialized
DEBUG - 2025-05-23 17:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:26:29 --> Input Class Initialized
INFO - 2025-05-23 17:26:29 --> Language Class Initialized
INFO - 2025-05-23 17:26:29 --> Loader Class Initialized
INFO - 2025-05-23 17:26:29 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:26:29 --> Controller Class Initialized
DEBUG - 2025-05-23 17:26:29 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 17:26:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 17:26:29 --> Model "Profile_model" initialized
INFO - 2025-05-23 17:26:29 --> Helper loaded: inflector_helper
INFO - 2025-05-23 17:26:29 --> Final output sent to browser
DEBUG - 2025-05-23 17:26:29 --> Total execution time: 0.0297
ERROR - 2025-05-23 17:26:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:26:38 --> Config Class Initialized
INFO - 2025-05-23 17:26:38 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:26:38 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:26:38 --> Utf8 Class Initialized
INFO - 2025-05-23 17:26:38 --> URI Class Initialized
INFO - 2025-05-23 17:26:38 --> Router Class Initialized
INFO - 2025-05-23 17:26:38 --> Output Class Initialized
INFO - 2025-05-23 17:26:38 --> Security Class Initialized
DEBUG - 2025-05-23 17:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:26:38 --> Input Class Initialized
INFO - 2025-05-23 17:26:38 --> Language Class Initialized
INFO - 2025-05-23 17:26:38 --> Loader Class Initialized
INFO - 2025-05-23 17:26:38 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:26:38 --> Controller Class Initialized
DEBUG - 2025-05-23 17:26:38 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 17:26:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 17:26:38 --> Model "Profile_model" initialized
INFO - 2025-05-23 17:26:38 --> Helper loaded: inflector_helper
INFO - 2025-05-23 17:26:38 --> Final output sent to browser
DEBUG - 2025-05-23 17:26:38 --> Total execution time: 0.0304
ERROR - 2025-05-23 17:27:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:27:33 --> Config Class Initialized
INFO - 2025-05-23 17:27:33 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:27:33 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:27:33 --> Utf8 Class Initialized
ERROR - 2025-05-23 17:27:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:27:56 --> Config Class Initialized
INFO - 2025-05-23 17:27:56 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:27:56 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:27:56 --> Utf8 Class Initialized
ERROR - 2025-05-23 17:28:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:28:05 --> Config Class Initialized
INFO - 2025-05-23 17:28:05 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:28:05 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:28:05 --> Utf8 Class Initialized
INFO - 2025-05-23 17:28:05 --> URI Class Initialized
INFO - 2025-05-23 17:28:05 --> Router Class Initialized
INFO - 2025-05-23 17:28:05 --> Output Class Initialized
INFO - 2025-05-23 17:28:05 --> Security Class Initialized
DEBUG - 2025-05-23 17:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:28:05 --> Input Class Initialized
INFO - 2025-05-23 17:28:05 --> Language Class Initialized
INFO - 2025-05-23 17:28:05 --> Loader Class Initialized
INFO - 2025-05-23 17:28:05 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:28:05 --> Controller Class Initialized
DEBUG - 2025-05-23 17:28:05 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 17:28:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 17:28:05 --> Model "Profile_model" initialized
INFO - 2025-05-23 17:28:05 --> Helper loaded: inflector_helper
INFO - 2025-05-23 17:28:05 --> Final output sent to browser
DEBUG - 2025-05-23 17:28:05 --> Total execution time: 0.0446
ERROR - 2025-05-23 17:30:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:30:06 --> Config Class Initialized
INFO - 2025-05-23 17:30:06 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:30:06 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:30:06 --> Utf8 Class Initialized
INFO - 2025-05-23 17:30:06 --> URI Class Initialized
INFO - 2025-05-23 17:30:06 --> Router Class Initialized
INFO - 2025-05-23 17:30:06 --> Output Class Initialized
INFO - 2025-05-23 17:30:06 --> Security Class Initialized
DEBUG - 2025-05-23 17:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:30:06 --> Input Class Initialized
INFO - 2025-05-23 17:30:06 --> Language Class Initialized
INFO - 2025-05-23 17:30:06 --> Loader Class Initialized
INFO - 2025-05-23 17:30:06 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:30:06 --> Controller Class Initialized
DEBUG - 2025-05-23 17:30:06 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 17:30:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 17:30:06 --> Model "Profile_model" initialized
INFO - 2025-05-23 17:30:06 --> Helper loaded: inflector_helper
INFO - 2025-05-23 17:30:06 --> Final output sent to browser
DEBUG - 2025-05-23 17:30:06 --> Total execution time: 0.0322
ERROR - 2025-05-23 17:31:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:31:59 --> Config Class Initialized
INFO - 2025-05-23 17:31:59 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:31:59 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:31:59 --> Utf8 Class Initialized
INFO - 2025-05-23 17:31:59 --> URI Class Initialized
INFO - 2025-05-23 17:31:59 --> Router Class Initialized
INFO - 2025-05-23 17:31:59 --> Output Class Initialized
INFO - 2025-05-23 17:31:59 --> Security Class Initialized
DEBUG - 2025-05-23 17:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:31:59 --> Input Class Initialized
INFO - 2025-05-23 17:31:59 --> Language Class Initialized
INFO - 2025-05-23 17:31:59 --> Loader Class Initialized
INFO - 2025-05-23 17:31:59 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:31:59 --> Controller Class Initialized
DEBUG - 2025-05-23 17:31:59 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 17:31:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 17:31:59 --> Model "Profile_model" initialized
INFO - 2025-05-23 17:31:59 --> Helper loaded: inflector_helper
INFO - 2025-05-23 17:31:59 --> Final output sent to browser
DEBUG - 2025-05-23 17:31:59 --> Total execution time: 0.0342
ERROR - 2025-05-23 17:32:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:32:26 --> Config Class Initialized
INFO - 2025-05-23 17:32:26 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:32:26 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:32:26 --> Utf8 Class Initialized
INFO - 2025-05-23 17:32:26 --> URI Class Initialized
INFO - 2025-05-23 17:32:26 --> Router Class Initialized
INFO - 2025-05-23 17:32:26 --> Output Class Initialized
INFO - 2025-05-23 17:32:26 --> Security Class Initialized
DEBUG - 2025-05-23 17:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:32:26 --> Input Class Initialized
INFO - 2025-05-23 17:32:26 --> Language Class Initialized
INFO - 2025-05-23 17:32:26 --> Loader Class Initialized
INFO - 2025-05-23 17:32:26 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:32:26 --> Controller Class Initialized
DEBUG - 2025-05-23 17:32:26 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 17:32:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 17:32:26 --> Model "Profile_model" initialized
INFO - 2025-05-23 17:32:26 --> Helper loaded: inflector_helper
INFO - 2025-05-23 17:32:26 --> Final output sent to browser
DEBUG - 2025-05-23 17:32:26 --> Total execution time: 0.0285
ERROR - 2025-05-23 17:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:34:08 --> Config Class Initialized
INFO - 2025-05-23 17:34:08 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:34:08 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:34:08 --> Utf8 Class Initialized
INFO - 2025-05-23 17:34:08 --> URI Class Initialized
INFO - 2025-05-23 17:34:08 --> Router Class Initialized
INFO - 2025-05-23 17:34:08 --> Output Class Initialized
INFO - 2025-05-23 17:34:08 --> Security Class Initialized
DEBUG - 2025-05-23 17:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:34:08 --> Input Class Initialized
INFO - 2025-05-23 17:34:08 --> Language Class Initialized
INFO - 2025-05-23 17:34:08 --> Loader Class Initialized
INFO - 2025-05-23 17:34:08 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:34:08 --> Controller Class Initialized
DEBUG - 2025-05-23 17:34:08 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 17:34:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 17:34:08 --> Model "Profile_model" initialized
INFO - 2025-05-23 17:34:08 --> Helper loaded: inflector_helper
INFO - 2025-05-23 17:34:08 --> Final output sent to browser
DEBUG - 2025-05-23 17:34:08 --> Total execution time: 0.0334
ERROR - 2025-05-23 17:34:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 17:34:57 --> Config Class Initialized
INFO - 2025-05-23 17:34:57 --> Hooks Class Initialized
DEBUG - 2025-05-23 17:34:57 --> UTF-8 Support Enabled
INFO - 2025-05-23 17:34:57 --> Utf8 Class Initialized
INFO - 2025-05-23 17:34:57 --> URI Class Initialized
INFO - 2025-05-23 17:34:57 --> Router Class Initialized
INFO - 2025-05-23 17:34:57 --> Output Class Initialized
INFO - 2025-05-23 17:34:57 --> Security Class Initialized
DEBUG - 2025-05-23 17:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 17:34:57 --> Input Class Initialized
INFO - 2025-05-23 17:34:57 --> Language Class Initialized
INFO - 2025-05-23 17:34:57 --> Loader Class Initialized
INFO - 2025-05-23 17:34:57 --> Database Driver Class Initialized
DEBUG - 2025-05-23 17:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 17:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 17:34:57 --> Controller Class Initialized
DEBUG - 2025-05-23 17:34:57 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 17:34:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 17:34:57 --> Model "Profile_model" initialized
INFO - 2025-05-23 17:34:57 --> Helper loaded: inflector_helper
INFO - 2025-05-23 17:34:57 --> Final output sent to browser
DEBUG - 2025-05-23 17:34:57 --> Total execution time: 0.0301
ERROR - 2025-05-23 18:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:22:53 --> Config Class Initialized
INFO - 2025-05-23 18:22:53 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:22:53 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:22:53 --> Utf8 Class Initialized
INFO - 2025-05-23 18:22:53 --> URI Class Initialized
INFO - 2025-05-23 18:22:53 --> Router Class Initialized
INFO - 2025-05-23 18:22:53 --> Output Class Initialized
INFO - 2025-05-23 18:22:53 --> Security Class Initialized
DEBUG - 2025-05-23 18:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:22:53 --> Input Class Initialized
INFO - 2025-05-23 18:22:53 --> Language Class Initialized
INFO - 2025-05-23 18:22:53 --> Loader Class Initialized
INFO - 2025-05-23 18:22:53 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:22:53 --> Controller Class Initialized
DEBUG - 2025-05-23 18:22:53 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 18:22:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 18:22:53 --> Model "Profile_model" initialized
INFO - 2025-05-23 18:22:53 --> Helper loaded: inflector_helper
INFO - 2025-05-23 18:22:53 --> Final output sent to browser
DEBUG - 2025-05-23 18:22:53 --> Total execution time: 0.0446
ERROR - 2025-05-23 18:23:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:23:02 --> Config Class Initialized
INFO - 2025-05-23 18:23:02 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:23:02 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:23:02 --> Utf8 Class Initialized
INFO - 2025-05-23 18:23:02 --> URI Class Initialized
INFO - 2025-05-23 18:23:02 --> Router Class Initialized
INFO - 2025-05-23 18:23:02 --> Output Class Initialized
INFO - 2025-05-23 18:23:02 --> Security Class Initialized
DEBUG - 2025-05-23 18:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:23:02 --> Input Class Initialized
INFO - 2025-05-23 18:23:02 --> Language Class Initialized
INFO - 2025-05-23 18:23:02 --> Loader Class Initialized
INFO - 2025-05-23 18:23:02 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:23:02 --> Controller Class Initialized
DEBUG - 2025-05-23 18:23:02 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 18:23:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 18:23:02 --> Model "Profile_model" initialized
INFO - 2025-05-23 18:23:02 --> Helper loaded: inflector_helper
INFO - 2025-05-23 18:23:02 --> Final output sent to browser
DEBUG - 2025-05-23 18:23:02 --> Total execution time: 0.0340
ERROR - 2025-05-23 18:23:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:23:17 --> Config Class Initialized
INFO - 2025-05-23 18:23:17 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:23:17 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:23:17 --> Utf8 Class Initialized
INFO - 2025-05-23 18:23:17 --> URI Class Initialized
INFO - 2025-05-23 18:23:17 --> Router Class Initialized
INFO - 2025-05-23 18:23:17 --> Output Class Initialized
INFO - 2025-05-23 18:23:17 --> Security Class Initialized
DEBUG - 2025-05-23 18:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:23:17 --> Input Class Initialized
INFO - 2025-05-23 18:23:17 --> Language Class Initialized
INFO - 2025-05-23 18:23:17 --> Loader Class Initialized
INFO - 2025-05-23 18:23:17 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:23:17 --> Controller Class Initialized
DEBUG - 2025-05-23 18:23:17 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 18:23:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 18:23:17 --> Model "Profile_model" initialized
INFO - 2025-05-23 18:23:17 --> Helper loaded: inflector_helper
INFO - 2025-05-23 18:23:17 --> Final output sent to browser
DEBUG - 2025-05-23 18:23:17 --> Total execution time: 0.0315
ERROR - 2025-05-23 18:23:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:23:44 --> Config Class Initialized
INFO - 2025-05-23 18:23:44 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:23:44 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:23:44 --> Utf8 Class Initialized
INFO - 2025-05-23 18:23:44 --> URI Class Initialized
INFO - 2025-05-23 18:23:44 --> Router Class Initialized
INFO - 2025-05-23 18:23:44 --> Output Class Initialized
INFO - 2025-05-23 18:23:44 --> Security Class Initialized
DEBUG - 2025-05-23 18:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:23:44 --> Input Class Initialized
INFO - 2025-05-23 18:23:44 --> Language Class Initialized
INFO - 2025-05-23 18:23:44 --> Loader Class Initialized
INFO - 2025-05-23 18:23:44 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:23:44 --> Controller Class Initialized
ERROR - 2025-05-23 18:23:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:23:53 --> Config Class Initialized
INFO - 2025-05-23 18:23:53 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:23:53 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:23:53 --> Utf8 Class Initialized
INFO - 2025-05-23 18:23:53 --> URI Class Initialized
INFO - 2025-05-23 18:23:53 --> Router Class Initialized
INFO - 2025-05-23 18:23:53 --> Output Class Initialized
INFO - 2025-05-23 18:23:53 --> Security Class Initialized
DEBUG - 2025-05-23 18:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:23:53 --> Input Class Initialized
INFO - 2025-05-23 18:23:53 --> Language Class Initialized
INFO - 2025-05-23 18:23:53 --> Loader Class Initialized
INFO - 2025-05-23 18:23:53 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:23:53 --> Controller Class Initialized
DEBUG - 2025-05-23 18:23:53 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 18:23:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 18:23:53 --> Model "Profile_model" initialized
INFO - 2025-05-23 18:23:53 --> Helper loaded: inflector_helper
INFO - 2025-05-23 18:23:53 --> Final output sent to browser
DEBUG - 2025-05-23 18:23:53 --> Total execution time: 0.0287
ERROR - 2025-05-23 18:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:24:17 --> Config Class Initialized
INFO - 2025-05-23 18:24:17 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:24:17 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:24:17 --> Utf8 Class Initialized
INFO - 2025-05-23 18:24:17 --> URI Class Initialized
INFO - 2025-05-23 18:24:17 --> Router Class Initialized
INFO - 2025-05-23 18:24:17 --> Output Class Initialized
INFO - 2025-05-23 18:24:17 --> Security Class Initialized
DEBUG - 2025-05-23 18:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:24:17 --> Input Class Initialized
INFO - 2025-05-23 18:24:17 --> Language Class Initialized
INFO - 2025-05-23 18:24:17 --> Loader Class Initialized
INFO - 2025-05-23 18:24:17 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:24:17 --> Controller Class Initialized
DEBUG - 2025-05-23 18:24:17 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 18:24:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 18:24:17 --> Model "Profile_model" initialized
INFO - 2025-05-23 18:24:17 --> Helper loaded: inflector_helper
INFO - 2025-05-23 18:24:17 --> Final output sent to browser
DEBUG - 2025-05-23 18:24:17 --> Total execution time: 0.0309
ERROR - 2025-05-23 18:27:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:27:05 --> Config Class Initialized
INFO - 2025-05-23 18:27:05 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:27:05 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:27:05 --> Utf8 Class Initialized
INFO - 2025-05-23 18:27:05 --> URI Class Initialized
INFO - 2025-05-23 18:27:05 --> Router Class Initialized
INFO - 2025-05-23 18:27:05 --> Output Class Initialized
INFO - 2025-05-23 18:27:05 --> Security Class Initialized
DEBUG - 2025-05-23 18:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:27:05 --> Input Class Initialized
INFO - 2025-05-23 18:27:05 --> Language Class Initialized
INFO - 2025-05-23 18:27:05 --> Loader Class Initialized
INFO - 2025-05-23 18:27:05 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:27:05 --> Controller Class Initialized
DEBUG - 2025-05-23 18:27:05 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 18:27:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 18:27:05 --> Model "Profile_model" initialized
INFO - 2025-05-23 18:27:05 --> Helper loaded: inflector_helper
INFO - 2025-05-23 18:27:05 --> Final output sent to browser
DEBUG - 2025-05-23 18:27:05 --> Total execution time: 0.0474
ERROR - 2025-05-23 18:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:29:01 --> Config Class Initialized
INFO - 2025-05-23 18:29:01 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:29:01 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:29:01 --> Utf8 Class Initialized
INFO - 2025-05-23 18:29:01 --> URI Class Initialized
INFO - 2025-05-23 18:29:01 --> Router Class Initialized
INFO - 2025-05-23 18:29:01 --> Output Class Initialized
INFO - 2025-05-23 18:29:01 --> Security Class Initialized
DEBUG - 2025-05-23 18:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:29:01 --> Input Class Initialized
INFO - 2025-05-23 18:29:01 --> Language Class Initialized
INFO - 2025-05-23 18:29:01 --> Loader Class Initialized
INFO - 2025-05-23 18:29:01 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:29:01 --> Controller Class Initialized
DEBUG - 2025-05-23 18:29:01 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 18:29:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 18:29:01 --> Model "Profile_model" initialized
ERROR - 2025-05-23 18:29:01 --> Severity: error --> Exception: Call to undefined method Profile_model::get_profile_by_id() C:\wamp64\www\event_app\application\controllers\api\Profile.php 92
ERROR - 2025-05-23 18:29:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:29:39 --> Config Class Initialized
INFO - 2025-05-23 18:29:39 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:29:39 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:29:39 --> Utf8 Class Initialized
INFO - 2025-05-23 18:29:39 --> URI Class Initialized
INFO - 2025-05-23 18:29:39 --> Router Class Initialized
INFO - 2025-05-23 18:29:39 --> Output Class Initialized
INFO - 2025-05-23 18:29:39 --> Security Class Initialized
DEBUG - 2025-05-23 18:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:29:39 --> Input Class Initialized
INFO - 2025-05-23 18:29:39 --> Language Class Initialized
INFO - 2025-05-23 18:29:39 --> Loader Class Initialized
INFO - 2025-05-23 18:29:39 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:29:39 --> Controller Class Initialized
DEBUG - 2025-05-23 18:29:39 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 18:29:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 18:29:39 --> Model "Profile_model" initialized
ERROR - 2025-05-23 18:29:39 --> Severity: error --> Exception: Call to undefined method Profile_model::get_profile_by_id() C:\wamp64\www\event_app\application\controllers\api\Profile.php 92
ERROR - 2025-05-23 18:32:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:32:14 --> Config Class Initialized
INFO - 2025-05-23 18:32:14 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:32:14 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:32:14 --> Utf8 Class Initialized
INFO - 2025-05-23 18:32:14 --> URI Class Initialized
INFO - 2025-05-23 18:32:14 --> Router Class Initialized
INFO - 2025-05-23 18:32:14 --> Output Class Initialized
INFO - 2025-05-23 18:32:14 --> Security Class Initialized
DEBUG - 2025-05-23 18:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:32:14 --> Input Class Initialized
INFO - 2025-05-23 18:32:14 --> Language Class Initialized
INFO - 2025-05-23 18:32:14 --> Loader Class Initialized
INFO - 2025-05-23 18:32:14 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:32:14 --> Controller Class Initialized
DEBUG - 2025-05-23 18:32:14 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 18:32:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 18:32:14 --> Model "Profile_model" initialized
ERROR - 2025-05-23 18:32:14 --> Severity: error --> Exception: Call to undefined method Profile_model::get_profile_by_id() C:\wamp64\www\event_app\application\controllers\api\Profile.php 92
ERROR - 2025-05-23 18:32:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:32:40 --> Config Class Initialized
INFO - 2025-05-23 18:32:40 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:32:40 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:32:40 --> Utf8 Class Initialized
INFO - 2025-05-23 18:32:40 --> URI Class Initialized
INFO - 2025-05-23 18:32:40 --> Router Class Initialized
INFO - 2025-05-23 18:32:40 --> Output Class Initialized
INFO - 2025-05-23 18:32:40 --> Security Class Initialized
DEBUG - 2025-05-23 18:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:32:40 --> Input Class Initialized
INFO - 2025-05-23 18:32:40 --> Language Class Initialized
INFO - 2025-05-23 18:32:40 --> Loader Class Initialized
INFO - 2025-05-23 18:32:40 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:32:40 --> Controller Class Initialized
DEBUG - 2025-05-23 18:32:40 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 18:32:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 18:32:40 --> Model "Profile_model" initialized
ERROR - 2025-05-23 18:32:40 --> Severity: error --> Exception: Call to undefined method Profile_model::get_profile_by_id() C:\wamp64\www\event_app\application\controllers\api\Profile.php 92
ERROR - 2025-05-23 18:32:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2025-05-23 18:32:43 --> Config Class Initialized
INFO - 2025-05-23 18:32:43 --> Hooks Class Initialized
DEBUG - 2025-05-23 18:32:43 --> UTF-8 Support Enabled
INFO - 2025-05-23 18:32:43 --> Utf8 Class Initialized
INFO - 2025-05-23 18:32:43 --> URI Class Initialized
INFO - 2025-05-23 18:32:43 --> Router Class Initialized
INFO - 2025-05-23 18:32:43 --> Output Class Initialized
INFO - 2025-05-23 18:32:43 --> Security Class Initialized
DEBUG - 2025-05-23 18:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 18:32:43 --> Input Class Initialized
INFO - 2025-05-23 18:32:43 --> Language Class Initialized
INFO - 2025-05-23 18:32:43 --> Loader Class Initialized
INFO - 2025-05-23 18:32:43 --> Database Driver Class Initialized
DEBUG - 2025-05-23 18:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 18:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 18:32:44 --> Controller Class Initialized
DEBUG - 2025-05-23 18:32:44 --> Config file loaded: C:\wamp64\www\event_app\application\config/rest.php
INFO - 2025-05-23 18:32:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2025-05-23 18:32:44 --> Model "Profile_model" initialized
ERROR - 2025-05-23 18:32:44 --> Severity: error --> Exception: Call to undefined method Profile_model::get_profile_by_id() C:\wamp64\www\event_app\application\controllers\api\Profile.php 92
